# KMDV School Management System - macOS

## How to Run

1. Open Terminal (or double-click the executable)
2. Navigate to this folder:
   cd path/to/KMDV-School-macOS

3. Run the application:
   ./kmdv_school

4. Open your browser and go to:
   http://localhost:8000

## Demo Login Credentials

**School Login:**
- School Code: demohigh
- Password: demo123

OR

- School Code: stmarys
- Password: mary123

**User Login (after school login):**
- Username: admin
- Password: admin123

## Data Storage

**IMPORTANT:** Your data is stored in this folder:

    KMDV-School-macOS/backend/data/school.db

- All your data is saved in this database file
- You can backup this file to preserve your data
- To reset to demo data, restore from the original ZIP
- Keep this entire folder together - don't move just the executable

## Stopping the Server

Press Ctrl+C in the terminal to stop the server.

## Troubleshooting

### Permission Denied Error
If you get a permission denied error, run:
```bash
chmod +x kmdv_school
```

### macOS Security Warning
If macOS blocks the app:
1. Go to System Preferences > Security & Privacy
2. Click "Open Anyway" for kmdv_school

### Port Already in Use
If port 8000 is busy, stop other applications using that port.

### Data Not Saving
Check that the backend/data/ folder is writable.
Your data is saved in backend/data/school.db in the extracted folder.

## Support
For issues, please contact your administrator.
