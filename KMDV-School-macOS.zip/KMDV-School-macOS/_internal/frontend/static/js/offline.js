// Offline Detection and Handling

const Offline = {
    isOnline: navigator.onLine,

    // Initialize offline detection
    init() {
        this.updateStatus();

        window.addEventListener('online', () => {
            this.isOnline = true;
            this.updateStatus();
            this.onOnline();
        });

        window.addEventListener('offline', () => {
            this.isOnline = false;
            this.updateStatus();
            this.onOffline();
        });
    },

    // Update UI status
    updateStatus() {
        const statusEl = document.getElementById('syncStatus');
        if (statusEl) {
            if (this.isOnline) {
                statusEl.innerHTML = '<i class="bi bi-wifi"></i>';
                statusEl.classList.remove('offline');
                statusEl.title = 'Online';
            } else {
                statusEl.innerHTML = '<i class="bi bi-wifi-off"></i>';
                statusEl.classList.add('offline');
                statusEl.title = 'Offline';
            }
        }
    },

    // Handle online event
    onOnline() {
        console.log('Connection restored');
        if (window.Notification) {
            Notification.showSuccess('Connection restored. Syncing data...');
        }
        // Trigger sync if available
        if (window.Sync) {
            window.Sync.syncPendingData();
        }
    },

    // Handle offline event
    onOffline() {
        console.log('Connection lost');
        if (window.Notification) {
            Notification.showWarning('You are offline. Changes will be saved locally.');
        }
    }
};

// Initialize on load
Offline.init();

window.Offline = Offline;
