// Service Worker for PWA Offline Support

const CACHE_NAME = 'kmdv-school-v1';
const urlsToCache = [
    '/',
    '/static/css/bootstrap.min.css',
    '/static/css/bootstrap-icons.css',
    '/static/css/theme.css',
    '/static/css/main.css',
    '/static/css/mobile.css',
    '/static/css/components.css',
    '/static/js/bootstrap.bundle.min.js',
    '/static/js/chart.min.js',
    '/static/js/config.js',
    '/static/js/utils.js',
    '/static/js/api.js',
    '/static/js/auth.js',
    '/static/fonts/bootstrap-icons.woff2'
];

// Install event
self.addEventListener('install', (event) => {
    event.waitUntil(
        caches.open(CACHE_NAME)
            .then((cache) => {
                console.log('Opened cache');
                return cache.addAll(urlsToCache);
            })
    );
});

// Fetch event
self.addEventListener('fetch', (event) => {
    // Skip caching for API requests to avoid stale data issues
    if (event.request.url.includes('/api/') || 
        event.request.url.includes('/dashboard/') ||
        event.request.url.includes('/students/') ||
        event.request.url.includes('/payments/') ||
        event.request.url.includes('/fee-structure/')) {
        event.respondWith(
            fetch(event.request)
        );
        return;
    }
    
    event.respondWith(
        caches.match(event.request)
            .then((response) => {
                // Cache hit - return response
                if (response) {
                    return response;
                }

                // Clone the request
                const fetchRequest = event.request.clone();

                return fetch(fetchRequest).then((response) => {
                    // Check if valid response
                    if (!response || response.status !== 200 || response.type !== 'basic') {
                        return response;
                    }

                    // Clone the response
                    const responseToCache = response.clone();

                    caches.open(CACHE_NAME)
                        .then((cache) => {
                            cache.put(event.request, responseToCache);
                        });

                    return response;
                });
            })
    );
});

// Activate event
self.addEventListener('activate', (event) => {
    const cacheWhitelist = [CACHE_NAME];

    event.waitUntil(
        caches.keys().then((cacheNames) => {
            return Promise.all(
                cacheNames.map((cacheName) => {
                    if (cacheWhitelist.indexOf(cacheName) === -1) {
                        return caches.delete(cacheName);
                    }
                })
            );
        })
    );
});
