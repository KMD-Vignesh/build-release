// Payments Recording Page

let selectedStudent = null;
let selectedFees = [];
let studentPendingFees = null;
let selectedAcademicYear = null;

document.addEventListener('DOMContentLoaded', () => {
    if (!Auth.requireAuth()) return;

    loadClasses();
    initializePaymentControls();
    setTodayDate();
});

function setTodayDate() {
    const dateInput = document.getElementById('paymentDate');
    if (dateInput) {
        dateInput.value = Utils.getTodayDate();
    }
}

function loadClasses() {
    API.students.getClasses()
        .then(classes => {
            const classSelect = document.getElementById('classSelect');
            classSelect.innerHTML = '<option value="">Select Class</option>';

            classes.forEach(cls => {
                const option = document.createElement('option');
                option.value = cls;
                option.textContent = cls;
                classSelect.appendChild(option);
            });
        })
        .catch(error => {
            console.error('Failed to load classes:', error);
            Notification.showError('Failed to load classes');
        });

    // Add event listener for class selection
    document.getElementById('classSelect').addEventListener('change', function() {
        const classValue = this.value;
        const academicYearSelect = document.getElementById('academicYearSelect');
        const sectionSelect = document.getElementById('sectionSelect');

        if (classValue) {
            loadAcademicYearsForClass(classValue);
            academicYearSelect.disabled = false;

            // Reset downstream dropdowns
            sectionSelect.disabled = true;
            sectionSelect.innerHTML = '<option value="">Select Section</option>';
            document.getElementById('studentSelect').disabled = true;
            document.getElementById('studentSelect').innerHTML = '<option value="">Select Student</option>';
        } else {
            academicYearSelect.disabled = true;
            academicYearSelect.innerHTML = '<option value="">Select Year</option>';
            sectionSelect.disabled = true;
            sectionSelect.innerHTML = '<option value="">Select Section</option>';
            document.getElementById('studentSelect').disabled = true;
            document.getElementById('studentSelect').innerHTML = '<option value="">Select Student</option>';
        }
    });
}

async function loadAcademicYearsForClass(className) {
    const academicYearSelect = document.getElementById('academicYearSelect');
    academicYearSelect.innerHTML = '<option value="">Loading...</option>';

    try {
        // Get academic years that have fee structures for this class
        const response = await API.get('/fee-structure/', { class_name: className });

        // Extract unique academic years
        const uniqueYears = [...new Set(response.map(fee => fee.academic_year))];
        uniqueYears.sort().reverse(); // Latest year first

        if (uniqueYears.length === 0) {
            academicYearSelect.innerHTML = '<option value="">No fee structures found</option>';
            academicYearSelect.disabled = true;
            return;
        }

        academicYearSelect.innerHTML = '<option value="">Select Year</option>';
        uniqueYears.forEach(year => {
            const option = document.createElement('option');
            option.value = year;
            option.textContent = year;
            academicYearSelect.appendChild(option);
        });

        academicYearSelect.disabled = false;
    } catch (error) {
        console.error('Failed to load academic years:', error);
        academicYearSelect.innerHTML = '<option value="">Error loading years</option>';
        academicYearSelect.disabled = true;
    }
}

function loadSectionsForClass(className) {
    API.students.getSections({ class_name: className })
        .then(sections => {
            const sectionSelect = document.getElementById('sectionSelect');
            sectionSelect.innerHTML = '<option value="">Select Section</option>';

            sections.forEach(section => {
                const option = document.createElement('option');
                option.value = section;
                option.textContent = section;
                sectionSelect.appendChild(option);
            });
        })
        .catch(error => {
            console.error('Failed to load sections:', error);
            Notification.showError('Failed to load sections');
        });
}

let studentsList = {}; // Cache for student data

function loadStudentsForClassSection(className, section) {
    API.students.list({
        class_name: className,
        section: section,
        page_size: 100
    })
        .then(response => {
            const studentSelect = document.getElementById('studentSelect');
            studentSelect.innerHTML = '<option value="">Select Student</option>';

            studentsList = {}; // Clear cache

            (response.students || []).forEach(student => {
                const option = document.createElement('option');
                option.value = student.id;
                option.textContent = `${student.first_name} ${student.last_name} (${student.admission_number})`;
                studentSelect.appendChild(option);

                // Cache student data
                studentsList[student.id] = student;
            });
        })
        .catch(error => {
            console.error('Failed to load students:', error);
            Notification.showError('Failed to load students');
        });
}

function loadStudentPendingFees(studentId, academicYear) {
    // Show loading
    const feeRecordingSection = document.getElementById('feeRecordingSection');
    const noStudentMsg = document.getElementById('noStudentMessage');

    noStudentMsg.innerHTML = '<i class="bi bi-hourglass-split"></i> Loading pending fees...';

    API.payments.getPendingFees(studentId, academicYear)
        .then(data => {
            studentPendingFees = data;

            // Hide no student message and show form
            noStudentMsg.style.display = 'none';
            feeRecordingSection.style.display = 'block';

            // Populate fee type dropdown with pending fees
            const feeTypeSelect = document.getElementById('feeTypeSelect');
            feeTypeSelect.innerHTML = '<option value="">Select fee type</option>';

            if (data.pending_fees && data.pending_fees.length > 0) {
                data.pending_fees.forEach(fee => {
                    const option = document.createElement('option');
                    option.value = fee.fee_type;
                    option.textContent = fee.fee_label;
                    option.dataset.pendingAmount = fee.pending_amount;
                    option.dataset.feeLabel = fee.fee_label;
                    option.dataset.feeHint = fee.fee_hint;
                    option.dataset.term = fee.term;
                    feeTypeSelect.appendChild(option);
                });

                // Clear hints initially
                document.getElementById('feeTypeHint').textContent = '';
                document.getElementById('amountHint').textContent = '';
                document.getElementById('feeAmountInput').value = '';

                // Enable controls
                feeTypeSelect.disabled = false;
                document.getElementById('feeAmountInput').disabled = false;
                document.getElementById('addFeeBtn').disabled = false;

                Notification.showSuccess(`Loaded ${data.pending_fees.length} pending fee(s) for ${academicYear}`);
            } else {
                feeTypeSelect.innerHTML = '<option value="">No pending payments for ' + academicYear + '</option>';
                feeTypeSelect.disabled = true;
                document.getElementById('feeAmountInput').disabled = true;
                document.getElementById('addFeeBtn').disabled = true;

                // Clear hints when no pending fees
                document.getElementById('feeTypeHint').textContent = '';
                document.getElementById('amountHint').textContent = '';
                document.getElementById('feeAmountInput').value = '';

                Notification.showInfo(`No pending fees for ${academicYear}`);
            }
        })
        .catch(error => {
            console.error('Failed to load pending fees:', error);
            noStudentMsg.innerHTML = '<i class="bi bi-exclamation-triangle"></i> Failed to load pending fees';
            Notification.showError('Failed to load pending fees');
        });
}

function clearStudentSelections() {
    selectedStudent = null;
    studentPendingFees = null;
    selectedFees = [];
    selectedAcademicYear = null;
    studentsList = {};

    // Hide selected student card, show no student message
    document.getElementById('selectedStudentCard').style.display = 'none';
    document.getElementById('noStudentSelectedCard').style.display = 'block';

    // Reset dropdowns
    document.getElementById('classSelect').value = '';
    document.getElementById('academicYearSelect').value = '';
    document.getElementById('sectionSelect').value = '';
    document.getElementById('studentSelect').value = '';
    document.getElementById('academicYearSelect').disabled = true;
    document.getElementById('sectionSelect').disabled = true;
    document.getElementById('studentSelect').disabled = true;
    document.getElementById('studentSelect').innerHTML = '<option value="">Select Student</option>';
    document.getElementById('academicYearSelect').innerHTML = '<option value="">Select Year</option>';

    // Reset payment info
    document.getElementById('paymentMode').value = '';
    document.getElementById('paymentRemarks').value = '';
    document.getElementById('paymentModeRow').style.display = 'none';
    setTodayDate();

    // Reset fee type select and hints
    document.getElementById('feeTypeSelect').value = '';
    document.getElementById('feeTypeSelect').innerHTML = '<option value="">Select fee type</option>';
    document.getElementById('feeTypeHint').textContent = '';
    document.getElementById('amountHint').textContent = '';
    document.getElementById('feeAmountInput').value = '';

    // Hide fee recording section and show message
    document.getElementById('feeRecordingSection').style.display = 'none';
    document.getElementById('noStudentMessage').style.display = 'block';
    document.getElementById('noStudentMessage').innerHTML = '<i class="bi bi-info-circle"></i> Please select a student to record payment';

    // Reset form
    updateSelectedFeesList();
    updateTotal();
}

function removeFee(index) {
    selectedFees.splice(index, 1);
    updateSelectedFeesList();
    updateTotal();
    updateRecordButtonState();
}

function updateTotal() {
    const total = selectedFees.reduce((sum, fee) => sum + parseFloat(fee.amount || 0), 0);
    document.getElementById('totalAmount').textContent = Utils.formatCurrency(total);
}

function updateRecordButtonState() {
    const recordBtn = document.getElementById('recordPaymentBtn');
    const hasStudent = !!selectedStudent;
    const hasFees = selectedFees.length > 0;
    const paymentMode = document.getElementById('paymentMode').value;
    const paymentDate = document.getElementById('paymentDate').value;

    // Enable button only if all conditions are met
    recordBtn.disabled = !(hasStudent && hasFees && paymentMode && paymentDate);
}

function initializePaymentControls() {
    // Academic year change listener - clear and reload student/fee data
    document.getElementById('academicYearSelect').addEventListener('change', function() {
        const className = document.getElementById('classSelect').value;
        const yearValue = this.value;
        const sectionSelect = document.getElementById('sectionSelect');
        const studentSelect = document.getElementById('studentSelect');

        if (yearValue && className) {
            selectedAcademicYear = yearValue;

            // Clear student selection and fee data
            selectedStudent = null;
            selectedFees = [];
            studentPendingFees = null;
            studentsList = {};

            // Reset student-related UI
            document.getElementById('selectedStudentCard').style.display = 'none';
            document.getElementById('noStudentSelectedCard').style.display = 'block';
            document.getElementById('feeRecordingSection').style.display = 'none';
            document.getElementById('noStudentMessage').style.display = 'block';
            document.getElementById('noStudentMessage').innerHTML = '<i class="bi bi-info-circle"></i> Please select a student to record payment';

            // Clear fee type dropdown
            const feeTypeSelect = document.getElementById('feeTypeSelect');
            feeTypeSelect.innerHTML = '<option value="">Select fee type</option>';
            feeTypeSelect.disabled = true;
            document.getElementById('feeAmountInput').disabled = true;
            document.getElementById('addFeeBtn').disabled = true;

            // Reset selected fees list
            updateSelectedFeesList();
            updateTotal();
            updateRecordButtonState();

            // Load sections for the selected class
            loadSectionsForClass(className);
            sectionSelect.disabled = false;

            // Reset student dropdown
            studentSelect.disabled = true;
            studentSelect.innerHTML = '<option value="">Select Student</option>';
        } else {
            selectedAcademicYear = null;
            sectionSelect.disabled = true;
            sectionSelect.innerHTML = '<option value="">Select Section</option>';
            studentSelect.disabled = true;
            studentSelect.innerHTML = '<option value="">Select Student</option>';
        }
    });

    // Section change listener
    document.getElementById('sectionSelect').addEventListener('change', function() {
        const className = document.getElementById('classSelect').value;
        const sectionValue = this.value;
        const studentSelect = document.getElementById('studentSelect');

        if (sectionValue && className) {
            loadStudentsForClassSection(className, sectionValue);
            studentSelect.disabled = false;
        } else {
            studentSelect.disabled = true;
            studentSelect.innerHTML = '<option value="">Select Student</option>';
        }
    });

    // Student change listener
    document.getElementById('studentSelect').addEventListener('change', function() {
        const studentId = this.value;

        if (studentId) {
            // Get student data from cache
            const studentData = studentsList[studentId];

            if (studentData) {
                selectedStudent = {
                    id: studentId,
                    name: `${studentData.first_name} ${studentData.last_name}`,
                    admissionNumber: studentData.admission_number,
                    className: studentData.class_name,
                    section: studentData.section,
                    parentName: studentData.parent_name || 'N/A',
                    academicYear: selectedAcademicYear
                };

                // Show selected student card
                document.getElementById('selectedStudentCard').style.display = 'block';
                document.getElementById('noStudentSelectedCard').style.display = 'none';

                // Populate student information
                document.getElementById('selectedName').textContent = selectedStudent.name;
                document.getElementById('selectedAdmissionNo').textContent = selectedStudent.admissionNumber;
                document.getElementById('selectedClass').textContent = selectedStudent.className;
                document.getElementById('selectedSection').textContent = selectedStudent.section;
                document.getElementById('selectedParentName').textContent = selectedStudent.parentName;
                document.getElementById('selectedAcademicYearDisplay').textContent = selectedAcademicYear;

                // Load pending fees for this student and academic year
                loadStudentPendingFees(studentId, selectedAcademicYear);
            }
        }
    });

    // Fee type selection - show hint
    document.getElementById('feeTypeSelect').addEventListener('change', function() {
        const selectedOption = this.options[this.selectedIndex];
        const pendingAmount = selectedOption.dataset.pendingAmount;
        const feeHint = selectedOption.dataset.feeHint;
        const feeAmountInput = document.getElementById('feeAmountInput');

        if (pendingAmount && feeHint) {
            document.getElementById('feeTypeHint').textContent = feeHint;
            feeAmountInput.value = '';
            feeAmountInput.max = pendingAmount;
            document.getElementById('amountHint').textContent = `Maximum: ₹${parseFloat(pendingAmount).toFixed(2)}`;
        } else {
            document.getElementById('feeTypeHint').textContent = '';
            feeAmountInput.max = '';
            document.getElementById('amountHint').textContent = '';
        }
    });

    // Monitor payment mode and date changes
    document.getElementById('paymentMode').addEventListener('change', function() {
        updateRecordButtonState();

        // Update payment mode display in student card
        const paymentMode = this.value;
        if (paymentMode) {
            const modeText = this.options[this.selectedIndex].text;
            document.getElementById('selectedPaymentModeDisplay').textContent = modeText;
            document.getElementById('paymentModeRow').style.display = 'table-row';
        } else {
            document.getElementById('paymentModeRow').style.display = 'none';
        }
    });

    document.getElementById('paymentDate').addEventListener('change', updateRecordButtonState);

    // Add fee button
    document.getElementById('addFeeBtn').addEventListener('click', () => {
        const feeTypeSelect = document.getElementById('feeTypeSelect');
        const feeAmountInput = document.getElementById('feeAmountInput');

        const feeType = feeTypeSelect.value;
        const feeAmount = parseFloat(feeAmountInput.value);
        const selectedOption = feeTypeSelect.options[feeTypeSelect.selectedIndex];
        const pendingAmount = parseFloat(selectedOption.dataset.pendingAmount);

        if (!feeType) {
            Notification.showError('Please select a fee type');
            return;
        }

        if (isNaN(feeAmount) || feeAmount <= 0) {
            Notification.showError('Please enter a valid amount');
            return;
        }

        // Validate against pending amount
        if (feeAmount > pendingAmount) {
            Notification.showError(`Amount cannot exceed pending amount of ₹${pendingAmount.toFixed(2)}`);
            return;
        }

        // Check if fee type already exists
        const existingFeeIndex = selectedFees.findIndex(fee => fee.fee_type === feeType);
        if (existingFeeIndex !== -1) {
            Notification.showError('This fee type is already added. Remove it first to change the amount.');
            return;
        }

        // Add new fee
        selectedFees.push({
            fee_type: feeType,
            amount: feeAmount,
            fee_label: selectedOption.dataset.feeLabel || feeType,
            academic_year: selectedAcademicYear
        });

        Notification.showSuccess('Fee added successfully');

        // Update the UI
        updateSelectedFeesList();
        updateTotal();
        updateRecordButtonState();

        // Reset inputs
        feeTypeSelect.value = '';
        feeAmountInput.value = '';
        document.getElementById('feeTypeHint').textContent = '';
        document.getElementById('amountHint').textContent = '';
        feeTypeSelect.focus();
    });

    // Handle Enter key in amount input
    document.getElementById('feeAmountInput').addEventListener('keypress', (e) => {
        if (e.key === 'Enter') {
            e.preventDefault();
            document.getElementById('addFeeBtn').click();
        }
    });

    // Record payment button
    document.getElementById('recordPaymentBtn').addEventListener('click', async () => {
        if (!selectedStudent) {
            Notification.showError('Please select a student');
            return;
        }

        if (selectedFees.length === 0) {
            Notification.showError('Please add at least one fee');
            return;
        }

        const paymentMode = document.getElementById('paymentMode').value;
        const paymentDate = document.getElementById('paymentDate').value;
        const paymentRemarks = document.getElementById('paymentRemarks').value;

        if (!paymentMode) {
            Notification.showError('Please select payment mode');
            return;
        }

        if (!paymentDate) {
            Notification.showError('Please select payment date');
            return;
        }

        const submitBtn = document.getElementById('recordPaymentBtn');
        submitBtn.disabled = true;

        try {
            for (const fee of selectedFees) {
                const paymentData = {
                    student_id: selectedStudent.id,
                    fee_type: fee.fee_type,
                    amount: Number(fee.amount).toFixed(2),
                    payment_mode: paymentMode,
                    payment_date: paymentDate,
                    academic_year: selectedAcademicYear,
                    remarks: paymentRemarks || null
                };

                console.log('Sending payment data:', paymentData);
                await API.payments.create(paymentData);
            }

            Notification.showSuccess('Payment recorded successfully!');

            // Reset fees
            selectedFees = [];
            updateSelectedFeesList();
            updateTotal();
            updateRecordButtonState();

            // Reset payment info
            document.getElementById('paymentMode').value = '';
            document.getElementById('paymentRemarks').value = '';
            setTodayDate();

            // Reload pending fees
            if (selectedStudent && selectedAcademicYear) {
                loadStudentPendingFees(selectedStudent.id, selectedAcademicYear);
            }
        } catch (error) {
            console.error('Payment recording error:', error);
            let errorMessage = 'Failed to record payment';

            if (error && typeof error === 'object') {
                if (error.message) {
                    errorMessage = error.message;
                } else {
                    errorMessage = 'Payment data validation failed. Please check all fields are filled correctly.';
                }
            } else if (typeof error === 'string') {
                errorMessage = error;
            } else {
                errorMessage = 'An unexpected error occurred while recording payment.';
            }
            Notification.showError(errorMessage);
        } finally {
            submitBtn.disabled = false;
            updateRecordButtonState();
        }
    });
}

function updateSelectedFeesList() {
    const tbody = document.getElementById('selectedFeesList');

    if (selectedFees.length === 0) {
        tbody.innerHTML = `
            <tr id="noFeesRow">
                <td colspan="5" class="text-center text-muted py-5">
                    <i class="bi bi-inbox fs-1 d-block mb-2"></i>
                    No fees added yet
                </td>
            </tr>
        `;
        return;
    }

    tbody.innerHTML = '';
    selectedFees.forEach((fee, index) => {
        const row = document.createElement('tr');
        row.innerHTML = `
            <td>${fee.fee_label || fee.fee_type}</td>
            <td>${fee.academic_year || '-'}</td>
            <td>-</td>
            <td class="text-end">₹${parseFloat(fee.amount).toFixed(2)}</td>
            <td class="text-center">
                <button class="btn btn-sm btn-outline-danger" onclick="removeFee(${index})" title="Remove">
                    <i class="bi bi-trash"></i>
                </button>
            </td>
        `;
        tbody.appendChild(row);
    });
}
