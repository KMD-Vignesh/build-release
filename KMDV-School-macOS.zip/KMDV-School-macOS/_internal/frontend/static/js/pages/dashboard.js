// Dashboard Page

let currentDailyPage = 1;
const DAILY_PAGE_SIZE = 10;

document.addEventListener('DOMContentLoaded', () => {
    // Require authentication
    if (!Auth.requireAuth()) return;

    // Set role-based visibility
    setRoleBasedVisibility();

    loadDashboardData();
    initializeDailyPayments();
});

function setRoleBasedVisibility() {
    const user = Auth.getCurrentUser();
    if (!user) return;

    const adminStatsSection = document.getElementById('adminStatsSection');
    const adminTablesSection = document.getElementById('adminTablesSection');
    const dailyPaymentSection = document.getElementById('dailyPaymentSection');

    if (user.role === 'admin') {
        // Admin sees everything
        if (adminStatsSection) adminStatsSection.style.display = '';
        if (adminTablesSection) adminTablesSection.style.display = '';
        if (dailyPaymentSection) dailyPaymentSection.style.display = '';
    } else {
        // Other roles only see daily payment section
        if (adminStatsSection) adminStatsSection.style.display = 'none';
        if (adminTablesSection) adminTablesSection.style.display = 'none';
        if (dailyPaymentSection) dailyPaymentSection.style.display = '';
    }
}

async function loadDashboardData() {
    // Only load dashboard data for admin users
    const user = Auth.getCurrentUser();
    if (!user || user.role !== 'admin') {
        return;
    }

    try {
        const data = await API.dashboard.getData();
        console.log('Dashboard data:', data);

        // Update stats
        const stats = data.stats || {};
        document.getElementById('totalStudents').textContent = stats.total_students || 0;
        document.getElementById('totalCollection').textContent = Utils.formatCurrency(stats.total_collected || 0);
        document.getElementById('pendingAmount').textContent = Utils.formatCurrency(stats.total_pending || 0);
        document.getElementById('thisMonth').textContent = Utils.formatCurrency(stats.month_collection || 0);

        // Render fee types table
        if (data.fee_types && data.fee_types.length > 0) {
            renderFeeTypesTable(data.fee_types);
        } else {
            document.getElementById('feeTypesTable').innerHTML = '<tr><td colspan="3" class="text-center text-muted">No fee types found</td></tr>';
        }

        // Render academic year summary table
        if (data.academic_year_summary && data.academic_year_summary.length > 0) {
            renderAcademicYearTable(data.academic_year_summary);
        } else {
            document.getElementById('academicYearTable').innerHTML = '<tr><td colspan="4" class="text-center text-muted">No data available</td></tr>';
        }

        // Render month summary table
        console.log('Month summary data:', data.month_summary);
        console.log('Month summary length:', data.month_summary ? data.month_summary.length : 'undefined');
        if (data.month_summary && data.month_summary.length > 0) {
            renderMonthSummaryTable(data.month_summary);
        } else {
            console.log('No month summary data found');
            document.getElementById('monthSummaryTable').innerHTML = '<tr><td colspan="3" class="text-center text-muted">No monthly data available</td></tr>';
        }
    } catch (error) {
        console.error('Failed to load dashboard:', error);
        Notification.showError('Failed to load dashboard data: ' + error.message);
    }
}

function renderFeeTypesTable(feeTypes) {
    const tbody = document.getElementById('feeTypesTable');
    if (!tbody) return;

    tbody.innerHTML = feeTypes.map(feeType => `
        <tr>
            <td><strong>${Utils.escapeHtml(feeType.code)}</strong></td>
            <td>${Utils.escapeHtml(feeType.name)}</td>
            <td class="text-muted">${Utils.escapeHtml(feeType.description || '-')}</td>
        </tr>
    `).join('');
}

function renderAcademicYearTable(academicYears) {
    const tbody = document.getElementById('academicYearTable');
    if (!tbody) return;

    tbody.innerHTML = academicYears.map(year => `
        <tr>
            <td><strong>${Utils.escapeHtml(year.academic_year)}</strong></td>
            <td class="text-success">${Utils.formatCurrency(year.total_collected)}</td>
            <td class="text-danger">${Utils.formatCurrency(year.total_pending)}</td>
            <td class="text-warning">${year.partial_students || 0} students</td>
        </tr>
    `).join('');
}

function renderMonthSummaryTable(monthSummary) {
    const tbody = document.getElementById('monthSummaryTable');
    if (!tbody) return;

    tbody.innerHTML = monthSummary.map(month => `
        <tr>
            <td><strong>${Utils.escapeHtml(month.month)}</strong></td>
            <td class="text-success">${Utils.formatCurrency(month.collected_amount)}</td>
            <td class="text-primary">${month.payment_count} payments</td>
        </tr>
    `).join('');
}

// Daily Payments Functions
function initializeDailyPayments() {
    const dateInput = document.getElementById('dailyPaymentDate');
    if (!dateInput) return;

    // Set default to today
    const today = new Date().toISOString().split('T')[0];
    dateInput.value = today;

    // Load daily payments
    loadDailyPayments();

    // Add event listener for date change
    dateInput.addEventListener('change', () => {
        currentDailyPage = 1;
        loadDailyPayments();
    });
}

async function loadDailyPayments(page = 1) {
    currentDailyPage = page;
    const dateInput = document.getElementById('dailyPaymentDate');
    const tbody = document.getElementById('dailyPaymentsTable');

    if (!dateInput || !tbody) return;

    const selectedDate = dateInput.value;

    try {
        Utils.showLoading(tbody, 'Loading...', 6);

        // Fetch summary stats and payment data in parallel
        const [summaryResponse, paymentsResponse] = await Promise.all([
            API.dashboard.getDailyPaymentsSummary({ payment_date: selectedDate }),
            API.dashboard.getDailyPayments({
                payment_date: selectedDate,
                page: page,
                page_size: DAILY_PAGE_SIZE
            })
        ]);

        // Update stats cards from summary
        document.getElementById('dailyPaymentCount').textContent = summaryResponse.total_count || 0;
        document.getElementById('dailyTotalAmount').textContent = Utils.formatCurrency(summaryResponse.total_amount || 0);
        document.getElementById('dailyCashAmount').textContent = Utils.formatCurrency(summaryResponse.cash_amount || 0);
        document.getElementById('dailyOnlineAmount').textContent = Utils.formatCurrency(summaryResponse.online_amount || 0);

        // Check if there are any payments
        if (!paymentsResponse.payments || paymentsResponse.payments.length === 0) {
            Utils.showEmpty(tbody, 'No payments found for this date', 6);
            document.getElementById('dailyPaymentsPagination').innerHTML = '';
            return;
        }

        // Render payment table
        tbody.innerHTML = paymentsResponse.payments.map(payment => `
            <tr>
                <td><strong>${Utils.escapeHtml(payment.receipt_number)}</strong></td>
                <td>${Utils.escapeHtml(payment.student_name)}</td>
                <td>${Utils.escapeHtml(payment.fee_type)}</td>
                <td class="text-success">${Utils.formatCurrency(payment.amount)}</td>
                <td><span class="badge bg-primary">${Utils.escapeHtml(payment.payment_mode)}</span></td>
                <td>${payment.payment_time}</td>
            </tr>
        `).join('');

        // Render pagination
        Utils.renderPagination({
            total: paymentsResponse.total,
            currentPage: page,
            pageSize: DAILY_PAGE_SIZE,
            elementId: 'dailyPaymentsPagination',
            onPageChange: 'loadDailyPayments'
        });
    } catch (error) {
        console.error('Failed to load daily payments:', error);
        Utils.showError(tbody, 'Failed to load daily payments', 6);
        Notification.showError('Failed to load daily payments');

        // Reset stats cards on error
        document.getElementById('dailyPaymentCount').textContent = '0';
        document.getElementById('dailyTotalAmount').textContent = '₹0';
        document.getElementById('dailyCashAmount').textContent = '₹0';
        document.getElementById('dailyOnlineAmount').textContent = '₹0';
    }
}

async function exportDailyPaymentsCSV() {
    const dateInput = document.getElementById('dailyPaymentDate');
    if (!dateInput) return;

    try {
        const selectedDate = dateInput.value;
        const token = localStorage.getItem(CONFIG.STORAGE_KEYS.AUTH_TOKEN);

        // Create download link
        const url = `${CONFIG.API_BASE_URL}/dashboard/daily-payments/export?payment_date=${selectedDate}`;

        const response = await fetch(url, {
            method: 'GET',
            headers: {
                'Authorization': `Bearer ${token}`
            }
        });

        if (!response.ok) {
            throw new Error('Export failed');
        }

        const blob = await response.blob();
        const downloadUrl = window.URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = downloadUrl;
        a.download = `daily_payments_${selectedDate}.csv`;
        document.body.appendChild(a);
        a.click();
        window.URL.revokeObjectURL(downloadUrl);
        a.remove();

        Notification.showSuccess('CSV exported successfully');
    } catch (error) {
        console.error('Export failed:', error);
        Notification.showError('Failed to export CSV');
    }
}
