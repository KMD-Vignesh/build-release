// Students Page

let currentPage = 1;
let currentFilters = {};
let allStudentsData = [];
const PAGE_SIZE = 10;

document.addEventListener('DOMContentLoaded', () => {
    if (!Auth.requireAuth()) return;

    loadStudents(1);
    initializeFilters();
    initializeAddStudentForm();
});

async function loadStudents(page = 1, refetch = true) {
    currentPage = page;
    const tbody = document.getElementById('studentsTable');

    try {
        // Only fetch if refetch is true (initial load or filter change)
        if (refetch) {
            Utils.showLoading(tbody);

            const params = { page: 1, page_size: 500, ...currentFilters };
            const response = await API.students.list(params);
            allStudentsData = response.students || [];
        }

        if (!allStudentsData || allStudentsData.length === 0) {
            Utils.showEmpty(tbody, 'No students found');
            document.getElementById('pagination').innerHTML = '';
            return;
        }

        // Client-side pagination
        const start = (page - 1) * PAGE_SIZE;
        const end = start + PAGE_SIZE;
        const paginatedData = allStudentsData.slice(start, end);

        tbody.innerHTML = paginatedData.map(student => `
            <tr>
                <td>${student.admission_number}</td>
                <td>${student.first_name} ${student.last_name}</td>
                <td>${student.class_name}</td>
                <td>${student.section}</td>
                <td>${student.phone || 'N/A'}</td>
                <td>
                    <button class="btn btn-sm btn-primary" onclick="editStudent('${student.id}')">
                        <i class="bi bi-pencil"></i>
                    </button>
                </td>
            </tr>
        `).join('');

        Utils.renderPagination({
            total: allStudentsData.length,
            currentPage: page,
            pageSize: PAGE_SIZE,
            elementId: 'pagination',
            onPageChange: 'renderStudentsPage'
        });
    } catch (error) {
        Utils.showError(tbody, 'Failed to load students');
        Notification.showError('Failed to load students');
    }
}

// Render specific page without refetching
function renderStudentsPage(page) {
    loadStudents(page, false);
}

function initializeFilters() {
    const searchInput = document.getElementById('searchStudent');
    const classFilter = document.getElementById('filterClass');
    const sectionFilter = document.getElementById('filterSection');

    if (searchInput) {
        searchInput.addEventListener('input', Utils.debounce((e) => {
            currentFilters.search = e.target.value;
            loadStudents(1);
        }, 500));
    }

    if (classFilter) {
        classFilter.addEventListener('change', (e) => {
            currentFilters.class_name = e.target.value;
            loadStudents(1);
        });
    }

    if (sectionFilter) {
        sectionFilter.addEventListener('change', (e) => {
            currentFilters.section = e.target.value;
            loadStudents(1);
        });
    }
}

function resetFilters() {
    currentFilters = {};
    document.getElementById('searchStudent').value = '';
    document.getElementById('filterClass').value = '';
    document.getElementById('filterSection').value = '';
    loadStudents(1);
}

function initializeAddStudentForm() {
    const form = document.getElementById('addStudentForm');
    if (!form) return;

    form.addEventListener('submit', async (e) => {
        e.preventDefault();

        const formData = new FormData(form);
        const data = Object.fromEntries(formData.entries());

        try {
            await API.students.create(data);
            Notification.showSuccess('Student added successfully');
            Modal.hide('addStudentModal');
            form.reset();
            loadStudents(currentPage);
        } catch (error) {
            Notification.showError(error.message || 'Failed to add student');
        }
    });
}

async function deleteStudent(id) {
    Modal.confirm('Are you sure you want to delete this student?', async () => {
        try {
            await API.students.delete(id);
            Notification.showSuccess('Student deleted successfully');
            loadStudents(currentPage);
        } catch (error) {
            Notification.showError('Failed to delete student');
        }
    });
}

