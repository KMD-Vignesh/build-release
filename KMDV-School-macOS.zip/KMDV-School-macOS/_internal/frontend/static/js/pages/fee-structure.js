// Fee Structure Management
let currentFilters = {
    academic_year: '',
    class_name: ''
};
let currentPage = 1;
let allFeeStructures = [];
const PAGE_SIZE = 10;

// Global variable to store fee types
let allFeeTypes = [];

// Format term display
function formatTerm(term) {
    const termMap = {
        'annual': 'Annual',
        'half_yearly': 'Half Yearly',
        'quarterly': 'Quarterly',
        'monthly': 'Monthly',
        'term1': 'Term 1',
        'term2': 'Term 2',
        'term3': 'Term 3'
    };
    return termMap[term] || term;
}

// Initialize page
document.addEventListener('DOMContentLoaded', function() {
    loadAcademicYears();
    loadFeeStructures(1);
    loadFeeTypesForDropdown();
    setupEventListeners();
    setupFeeTypesModal();
    initializeAcademicYearDropdowns();
});

// Initialize academic year dropdowns
function initializeAcademicYearDropdowns() {
    const currentYear = new Date().getFullYear();
    const startYearSelect = document.getElementById('startYear');
    const endYearSelect = document.getElementById('endYear');

    // Populate start year (from 5 years ago to 5 years ahead)
    for (let year = currentYear - 5; year <= currentYear + 5; year++) {
        const option = document.createElement('option');
        option.value = year;
        option.textContent = year;
        startYearSelect.appendChild(option);
    }

    // Set current year as default
    startYearSelect.value = currentYear;

    // Handle start year change
    startYearSelect.addEventListener('change', function() {
        const selectedYear = parseInt(this.value);
        if (selectedYear) {
            const nextYear = selectedYear + 1;
            endYearSelect.innerHTML = `<option value="${nextYear}">${nextYear}</option>`;
            endYearSelect.value = nextYear;
            endYearSelect.disabled = false;

            // Update academic year value (e.g., "2024-25")
            const academicYear = `${selectedYear}-${nextYear.toString().slice(-2)}`;
            document.getElementById('academicYearValue').value = academicYear;
        } else {
            endYearSelect.innerHTML = '<option value="">End Year</option>';
            endYearSelect.disabled = true;
            document.getElementById('academicYearValue').value = '';
        }
    });

    // Trigger change to set initial values
    if (currentYear) {
        startYearSelect.dispatchEvent(new Event('change'));
    }
}

// Load academic years for filter
async function loadAcademicYears() {
    try {
        const years = await API.get('/fee-structure/years');

        const filterSelect = document.getElementById('filterAcademicYear');
        filterSelect.innerHTML = '<option value="">All Years</option>';

        years.forEach(year => {
            const option = document.createElement('option');
            option.value = year;
            option.textContent = year;
            filterSelect.appendChild(option);
        });
    } catch (error) {
        console.error('Error loading academic years:', error);
    }
}

// Load fee structures - fetch data from API
async function loadFeeStructures(page = 1, refetch = true) {
    currentPage = page;
    const tableBody = document.getElementById('feeStructureTable');

    try {
        // Only fetch if refetch is true (initial load or filter change)
        if (refetch) {
            tableBody.innerHTML = '<tr><td colspan="7" class="text-center">Loading...</td></tr>';

            const params = {};
            if (currentFilters.academic_year) params.academic_year = currentFilters.academic_year;
            if (currentFilters.class_name) params.class_name = currentFilters.class_name;

            allFeeStructures = await API.get('/fee-structure/', params);
        }

        if (!allFeeStructures || allFeeStructures.length === 0) {
            tableBody.innerHTML = '<tr><td colspan="7" class="text-center">No fee structures found</td></tr>';
            document.getElementById('feeStructurePagination').innerHTML = '';
            return;
        }

        // Client-side pagination
        const start = (page - 1) * PAGE_SIZE;
        const end = start + PAGE_SIZE;
        const paginatedData = allFeeStructures.slice(start, end);

        tableBody.innerHTML = paginatedData.map(fee => `
            <tr>
                <td>${escapeHtml(fee.academic_year)}</td>
                <td>${escapeHtml(fee.class_name)}</td>
                <td>${escapeHtml(fee.fee_type)}</td>
                <td>${formatTerm(fee.term)}</td>
                <td>₹${parseFloat(fee.amount).toFixed(2)}</td>
                <td>
                    ${fee.is_active
                        ? '<span class="badge bg-success">Active</span>'
                        : '<span class="badge bg-secondary">Inactive</span>'}
                </td>
                <td>
                    <button class="btn btn-sm btn-primary" onclick="editFeeStructure('${fee.id}')">
                        <i class="bi bi-pencil"></i>
                    </button>
                    ${fee.is_active
                        ? `<button class="btn btn-sm btn-danger" onclick="deactivateFeeStructure('${fee.id}')">
                            <i class="bi bi-x-circle"></i>
                        </button>`
                        : `<button class="btn btn-sm btn-success" onclick="activateFeeStructure('${fee.id}')">
                            <i class="bi bi-check-circle"></i>
                        </button>`
                    }
                </td>
            </tr>
        `).join('');

        // Render pagination
        Utils.renderPagination({
            total: allFeeStructures.length,
            currentPage: page,
            pageSize: PAGE_SIZE,
            elementId: 'feeStructurePagination',
            onPageChange: 'renderFeeStructurePage'
        });
    } catch (error) {
        console.error('Error loading fee structures:', error);
        tableBody.innerHTML = `<tr><td colspan="7" class="text-center text-danger">Error: ${error.message}</td></tr>`;
    }
}

// Render specific page without refetching
function renderFeeStructurePage(page) {
    loadFeeStructures(page, false);
}

// Setup event listeners
function setupEventListeners() {
    // Filter change listeners
    document.getElementById('filterAcademicYear').addEventListener('change', function() {
        currentFilters.academic_year = this.value;
        loadFeeStructures(1);
    });

    document.getElementById('filterClass').addEventListener('change', function() {
        currentFilters.class_name = this.value;
        loadFeeStructures(1);
    });

    // Add fee structure form
    const addForm = document.getElementById('addFeeForm');
    addForm.addEventListener('submit', async function(e) {
        e.preventDefault();

        const formData = new FormData(addForm);
        const academicYear = document.getElementById('academicYearValue').value;

        // Get selected classes
        const selectedClasses = [];
        document.querySelectorAll('.class-checkbox:checked').forEach(checkbox => {
            selectedClasses.push(checkbox.value);
        });

        // Get selected fee types
        const selectedFeeTypes = [];
        document.querySelectorAll('.fee-type-checkbox:checked').forEach(checkbox => {
            selectedFeeTypes.push(checkbox.value);
        });

        if (selectedClasses.length === 0) {
            showAlert('Please select at least one class', 'warning');
            return;
        }

        if (selectedFeeTypes.length === 0) {
            showAlert('Please select at least one fee type', 'warning');
            return;
        }

        if (!academicYear) {
            showAlert('Please select academic year', 'warning');
            return;
        }

        try {
            let createdCount = 0;
            // Create fee structure for each combination of class and fee type
            for (const className of selectedClasses) {
                for (const feeType of selectedFeeTypes) {
                    const data = {
                        class_name: className,
                        fee_type: feeType,
                        amount: parseFloat(formData.get('amount')),
                        academic_year: academicYear,
                        term: formData.get('term'),
                        school_id: '' // Will be set by backend from auth
                    };

                    await API.post('/fee-structure/', data);
                    createdCount++;
                }
            }

            // Close modal
            const modal = bootstrap.Modal.getInstance(document.getElementById('addFeeModal'));
            modal.hide();

            // Reset form
            addForm.reset();
            document.querySelectorAll('.class-checkbox').forEach(cb => cb.checked = false);
            document.querySelectorAll('.fee-type-checkbox').forEach(cb => cb.checked = false);
            document.getElementById('academicYearValue').value = '';
            document.getElementById('startYear').value = '';
            document.getElementById('endYear').innerHTML = '<option value="">End Year</option>';
            document.getElementById('endYear').disabled = true;

            // Reload table
            await loadAcademicYears();
            await loadFeeStructures(1);

            showAlert(`Fee structure added successfully! Created ${createdCount} entries (${selectedClasses.length} classes × ${selectedFeeTypes.length} fee types)`, 'success');
        } catch (error) {
            console.error('Error adding fee structure:', error);
            showAlert('Error adding fee structure: ' + error.message, 'danger');
        }
    });

    // Edit fee structure form
    const editForm = document.getElementById('editFeeForm');
    editForm.addEventListener('submit', async function(e) {
        e.preventDefault();

        const feeId = document.getElementById('editFeeId').value;
        const amount = parseFloat(document.getElementById('editAmount').value);

        try {
            await API.put(`/fee-structure/${feeId}`, { amount });

            // Close modal
            const modal = bootstrap.Modal.getInstance(document.getElementById('editFeeModal'));
            modal.hide();

            // Reload table
            await loadFeeStructures(1);

            showAlert('Fee structure updated successfully!', 'success');
        } catch (error) {
            console.error('Error updating fee structure:', error);
            showAlert('Error updating fee structure: ' + error.message, 'danger');
        }
    });
}

// Edit fee structure
async function editFeeStructure(feeId) {
    try {
        const fee = await API.get(`/fee-structure/${feeId}`);

        document.getElementById('editFeeId').value = fee.id;
        document.getElementById('editAcademicYear').value = fee.academic_year;
        document.getElementById('editClass').value = fee.class_name;
        document.getElementById('editFeeType').value = fee.fee_type;
        document.getElementById('editTerm').value = formatTerm(fee.term);
        document.getElementById('editAmount').value = parseFloat(fee.amount);

        const modal = new bootstrap.Modal(document.getElementById('editFeeModal'));
        modal.show();
    } catch (error) {
        console.error('Error loading fee structure:', error);
        showAlert('Error loading fee structure: ' + error.message, 'danger');
    }
}

// Deactivate fee structure
async function deactivateFeeStructure(feeId) {
    Modal.confirm('Are you sure you want to deactivate this fee structure?', async () => {
        try {
            await API.put(`/fee-structure/${feeId}`, { is_active: false });
            await loadFeeStructures(currentPage);
            showAlert('Fee structure deactivated successfully!', 'success');
        } catch (error) {
            console.error('Error deactivating fee structure:', error);
            showAlert('Error deactivating fee structure: ' + error.message, 'danger');
        }
    });
}

// Activate fee structure
async function activateFeeStructure(feeId) {
    try {
        await API.put(`/fee-structure/${feeId}`, { is_active: true });
        await loadFeeStructures(currentPage);
        showAlert('Fee structure activated successfully!', 'success');
    } catch (error) {
        console.error('Error activating fee structure:', error);
        showAlert('Error activating fee structure: ' + error.message, 'danger');
    }
}

// Reset filters
function resetFilters() {
    currentFilters = {
        academic_year: '',
        class_name: ''
    };

    document.getElementById('filterAcademicYear').value = '';
    document.getElementById('filterClass').value = '';

    loadFeeStructures(1);
}

// Load fee types for dropdown
async function loadFeeTypesForDropdown() {
    try {
        const feeTypes = await API.feeTypes.list();
        allFeeTypes = feeTypes;

        const container = document.getElementById('feeTypesCheckboxContainer');
        container.innerHTML = '';

        if (feeTypes.length === 0) {
            container.innerHTML = '<p class="text-muted small">No fee types available</p>';
            return;
        }

        feeTypes.forEach(feeType => {
            const div = document.createElement('div');
            div.className = 'form-check';
            div.innerHTML = `
                <input class="form-check-input fee-type-checkbox" type="checkbox" value="${feeType.fee_code}" id="feeType_${feeType.fee_code}">
                <label class="form-check-label" for="feeType_${feeType.fee_code}">
                    ${feeType.fee_name}
                </label>
            `;
            container.appendChild(div);
        });
    } catch (error) {
        console.error('Error loading fee types:', error);
        document.getElementById('feeTypesCheckboxContainer').innerHTML = '<p class="text-danger small">Error loading fee types</p>';
    }
}

// Setup fee types modal
function setupFeeTypesModal() {
    // Load fee types when modal is shown
    document.getElementById('manageFeeTypesModal').addEventListener('show.bs.modal', loadFeeTypes);

    // Add fee type form
    const addFeeTypeForm = document.getElementById('addFeeTypeForm');
    addFeeTypeForm.addEventListener('submit', async function(e) {
        e.preventDefault();

        const feeName = document.getElementById('newFeeTypeName').value.trim();
        const feeCode = document.getElementById('newFeeTypeCode').value.trim();
        const description = document.getElementById('newFeeTypeDesc').value.trim();

        if (!feeName || !feeCode) {
            showAlert('Fee name and code are required', 'warning');
            return;
        }

        try {
            await API.feeTypes.create({
                fee_name: feeName,
                fee_code: feeCode,
                description: description || null
            });

            // Reset form
            addFeeTypeForm.reset();

            // Reload fee types
            await loadFeeTypes();
            await loadFeeTypesForDropdown();

            showAlert('Fee type added successfully!', 'success');
        } catch (error) {
            console.error('Error adding fee type:', error);
            showAlert('Error adding fee type: ' + error.message, 'danger');
        }
    });

    // Edit fee type form
    const editFeeTypeForm = document.getElementById('editFeeTypeForm');
    editFeeTypeForm.addEventListener('submit', async function(e) {
        e.preventDefault();

        const feeTypeId = document.getElementById('editFeeTypeId').value;
        const feeName = document.getElementById('editFeeTypeNameInput').value.trim();
        const feeCode = document.getElementById('editFeeTypeCodeInput').value.trim();
        const description = document.getElementById('editFeeTypeDescInput').value.trim();

        try {
            await API.feeTypes.update(feeTypeId, {
                fee_name: feeName,
                fee_code: feeCode,
                description: description || null
            });

            // Close modal
            const modal = bootstrap.Modal.getInstance(document.getElementById('editFeeTypeModal'));
            modal.hide();

            // Reload fee types
            await loadFeeTypes();
            await loadFeeTypesForDropdown();

            showAlert('Fee type updated successfully!', 'success');
        } catch (error) {
            console.error('Error updating fee type:', error);
            showAlert('Error updating fee type: ' + error.message, 'danger');
        }
    });
}

// Load fee types for management
async function loadFeeTypes() {
    const tbody = document.getElementById('feeTypesTableBody');
    tbody.innerHTML = '<tr><td colspan="5" class="text-center">Loading...</td></tr>';

    try {
        const feeTypes = await API.feeTypes.list(true); // Include inactive

        if (feeTypes.length === 0) {
            tbody.innerHTML = '<tr><td colspan="5" class="text-center">No fee types found</td></tr>';
            return;
        }

        tbody.innerHTML = feeTypes.map(feeType => `
            <tr>
                <td>${escapeHtml(feeType.fee_name)}</td>
                <td>${escapeHtml(feeType.fee_code)}</td>
                <td>${escapeHtml(feeType.description || '')}</td>
                <td>
                    ${feeType.is_active
                        ? '<span class="badge bg-success">Active</span>'
                        : '<span class="badge bg-secondary">Inactive</span>'}
                </td>
                <td>
                    <button class="btn btn-sm btn-primary" onclick="editFeeType('${feeType.id}')">
                        <i class="bi bi-pencil"></i>
                    </button>
                    ${feeType.is_active
                        ? `<button class="btn btn-sm btn-danger" onclick="deactivateFeeType('${feeType.id}')">
                            <i class="bi bi-x-circle"></i>
                        </button>`
                        : `<button class="btn btn-sm btn-success" onclick="activateFeeType('${feeType.id}')">
                            <i class="bi bi-check-circle"></i>
                        </button>`
                    }
                </td>
            </tr>
        `).join('');
    } catch (error) {
        console.error('Error loading fee types:', error);
        tbody.innerHTML = `<tr><td colspan="5" class="text-center text-danger">Error: ${error.message}</td></tr>`;
    }
}

// Edit fee type
async function editFeeType(feeTypeId) {
    try {
        const feeType = await API.feeTypes.get(feeTypeId);

        document.getElementById('editFeeTypeId').value = feeType.id;
        document.getElementById('editFeeTypeNameInput').value = feeType.fee_name;
        document.getElementById('editFeeTypeCodeInput').value = feeType.fee_code;
        document.getElementById('editFeeTypeDescInput').value = feeType.description || '';

        const modal = new bootstrap.Modal(document.getElementById('editFeeTypeModal'));
        modal.show();
    } catch (error) {
        console.error('Error loading fee type:', error);
        showAlert('Error loading fee type: ' + error.message, 'danger');
    }
}

// Deactivate fee type
async function deactivateFeeType(feeTypeId) {
    Modal.confirm('Are you sure you want to deactivate this fee type?', async () => {
        try {
            await API.feeTypes.update(feeTypeId, { is_active: false });
            await loadFeeTypes();
            await loadFeeTypesForDropdown();
            showAlert('Fee type deactivated successfully!', 'success');
        } catch (error) {
            console.error('Error deactivating fee type:', error);
            showAlert('Error deactivating fee type: ' + error.message, 'danger');
        }
    });
}

// Activate fee type
async function activateFeeType(feeTypeId) {
    try {
        await API.feeTypes.update(feeTypeId, { is_active: true });
        await loadFeeTypes();
        await loadFeeTypesForDropdown();
        showAlert('Fee type activated successfully!', 'success');
    } catch (error) {
        console.error('Error activating fee type:', error);
        showAlert('Error activating fee type: ' + error.message, 'danger');
    }
}

// Utility function to escape HTML
function escapeHtml(text) {
    const map = {
        '&': '&amp;',
        '<': '&lt;',
        '>': '&gt;',
        '"': '&quot;',
        "'": '&#039;'
    };
    return text ? text.toString().replace(/[&<>"']/g, m => map[m]) : '';
}

// Show alert
function showAlert(message, type = 'info') {
    Notification.show(message, type);
}
