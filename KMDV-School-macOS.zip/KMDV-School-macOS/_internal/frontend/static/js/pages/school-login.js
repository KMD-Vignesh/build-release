// School Login Page

document.addEventListener('DOMContentLoaded', () => {
    const form = document.getElementById('schoolLoginForm');

    form.addEventListener('submit', async (e) => {
        e.preventDefault();

        const schoolCode = document.getElementById('schoolCode').value.trim();
        const schoolPassword = document.getElementById('schoolPassword').value;

        if (!schoolCode || !schoolPassword) {
            Notification.showError('Please enter school code and password');
            return;
        }

        const submitBtn = form.querySelector('button[type="submit"]');
        const originalText = submitBtn.innerHTML;
        submitBtn.disabled = true;
        submitBtn.innerHTML = '<span class="spinner-border spinner-border-sm me-2"></span>Logging in...';

        try {
            const response = await API.auth.schoolLogin(schoolCode, schoolPassword);

            // Save school data
            Auth.saveSchoolData({
                school_id: response.school_id,
                school_code: schoolCode,
                school_name: response.school_name
            });

            Notification.showSuccess('School authenticated successfully!');

            // Redirect to user login
            setTimeout(() => {
                window.location.href = '/login/user';
            }, 500);
        } catch (error) {
            Notification.showError(error.message || 'Invalid school credentials');
            submitBtn.disabled = false;
            submitBtn.innerHTML = originalText;
        }
    });
});
