// Application Configuration

const CONFIG = {
    API_BASE_URL: window.location.origin,
    API_TIMEOUT: 30000,
    APP_NAME: 'KMDV School Management',
    APP_VERSION: '1.0.0',
    STORAGE_KEYS: {
        SCHOOL_DATA: 'kmdv_school_data',
        AUTH_TOKEN: 'kmdv_auth_token',
        USER_DATA: 'kmdv_user_data',
        THEME: 'kmdv_theme'
    },
    PAGINATION: {
        DEFAULT_PAGE_SIZE: 20,
        MAX_PAGE_SIZE: 100
    },
    CLASSES: ['LKG', 'UKG', '1', '2', '3', '4', '5', '6', '7', '8', '9', '10', '11', '12'],
    SECTIONS: ['A', 'B', 'C'],
    FEE_TYPES: [
        { value: 'tuition_fee', label: 'Tuition Fee' },
        { value: 'transport_fee', label: 'Transport Fee' },
        { value: 'uniform_fee', label: 'Uniform Fee' },
        { value: 'lab_fee', label: 'Lab Fee' },
        { value: 'library_fee', label: 'Library Fee' },
        { value: 'sports_fee', label: 'Sports Fee' }
    ],
    PAYMENT_MODES: [
        { value: 'cash', label: 'Cash' },
        { value: 'upi', label: 'UPI' },
        { value: 'card', label: 'Card' },
        { value: 'bank_transfer', label: 'Bank Transfer' },
        { value: 'cheque', label: 'Cheque' }
    ]
};

// Make config globally available
window.CONFIG = CONFIG;
