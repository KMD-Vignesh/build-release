// API Client

const API = {
    // Make API request
    async request(endpoint, options = {}) {
        const url = `${CONFIG.API_BASE_URL}${endpoint}`;
        const token = localStorage.getItem(CONFIG.STORAGE_KEYS.AUTH_TOKEN);

        const headers = {
            'Content-Type': 'application/json',
            ...options.headers
        };

        if (token) {
            headers['Authorization'] = `Bearer ${token}`;
        }

        const config = {
            ...options,
            headers,
            timeout: CONFIG.API_TIMEOUT
        };

        try {
            const response = await fetch(url, config);

            if (!response.ok) {
                let errorMessage = 'Request failed';
                try {
                    const errorData = await response.json();
                    console.error('API Error Response:', errorData);

                    // Handle FastAPI validation errors
                    if (errorData.detail) {
                        if (Array.isArray(errorData.detail)) {
                            // Pydantic validation errors
                            errorMessage = errorData.detail.map(err =>
                                `${err.loc.join('.')}: ${err.msg}`
                            ).join(', ');
                        } else {
                            errorMessage = errorData.detail;
                        }
                    } else {
                        errorMessage = errorData.message || JSON.stringify(errorData);
                    }
                } catch (e) {
                    errorMessage = response.statusText || 'Request failed';
                }
                throw new Error(errorMessage);
            }

            // Handle 204 No Content responses (e.g., DELETE)
            if (response.status === 204) {
                return null;
            }

            return await response.json();
        } catch (error) {
            console.error('API Error:', error);
            // Ensure we always throw an Error object with a message
            if (error instanceof Error) {
                throw error;
            }
            throw new Error(String(error));
        }
    },

    // GET request
    get(endpoint, params = {}) {
        const queryString = new URLSearchParams(params).toString();
        const url = queryString ? `${endpoint}?${queryString}` : endpoint;
        return this.request(url, { method: 'GET' });
    },

    // POST request
    post(endpoint, data) {
        return this.request(endpoint, {
            method: 'POST',
            body: JSON.stringify(data)
        });
    },

    // PUT request
    put(endpoint, data) {
        return this.request(endpoint, {
            method: 'PUT',
            body: JSON.stringify(data)
        });
    },

    // DELETE request
    delete(endpoint) {
        return this.request(endpoint, { method: 'DELETE' });
    },

    // Auth endpoints
    auth: {
        schoolLogin(schoolCode, password) {
            return API.post('/auth/school/login', { username: schoolCode, password });
        },

        userLogin(username, password) {
            // Get school data from localStorage
            const schoolData = localStorage.getItem(CONFIG.STORAGE_KEYS.SCHOOL_DATA);
            const school = schoolData ? JSON.parse(schoolData) : null;

            if (!school || !school.school_id) {
                throw new Error('School not authenticated. Please login with school credentials first.');
            }

            return API.post(`/auth/user/login?school_id=${school.school_id}`, { username, password });
        },

        logout() {
            return API.post('/auth/logout', {});
        }
    },

    // Student endpoints
    students: {
        list(params = {}) {
            return API.get('/students/', params);
        },

        get(id) {
            return API.get(`/students/${id}`);
        },

        create(data) {
            return API.post('/students/', data);
        },

        update(id, data) {
            return API.put(`/students/${id}`, data);
        },

        delete(id) {
            return API.delete(`/students/${id}`);
        },

        getClasses() {
            return API.get('/students/classes/list');
        },

        getSections(params = {}) {
            return API.get('/students/sections/list', params);
        }
    },

    // Payment endpoints
    payments: {
        list(params = {}) {
            return API.get('/payments/', params);
        },

        get(id) {
            return API.get(`/payments/${id}`);
        },

        getReceipt(id) {
            return API.get(`/payments/${id}/receipt`);
        },

        create(data) {
            return API.post('/payments/', data);
        },

        getByStudent(studentId) {
            return API.get(`/payments/student/${studentId}`);
        },

        getPendingFees(studentId, academicYear = null) {
            const params = academicYear ? { academic_year: academicYear } : {};
            return API.get(`/payments/pending/student/${studentId}`, params);
        },

        getSummary(params = {}) {
            return API.get('/payments/summary', params);
        },

        getDetailedTracking(params = {}) {
            return API.get('/payments/tracking/detailed', params);
        }
    },

    // Dashboard endpoints
    dashboard: {
        getData(params = {}) {
            return API.get('/dashboard/', params);
        },

        getDailyPayments(params = {}) {
            return API.get('/dashboard/daily-payments', params);
        },

        getDailyPaymentsSummary(params = {}) {
            return API.get('/dashboard/daily-payments/summary', params);
        }
    },

    // Fee Structure endpoints
    feeStructure: {
        list(params = {}) {
            return API.get('/fee-structure/', params);
        },

        get(id) {
            return API.get(`/fee-structure/${id}`);
        },

        create(data) {
            return API.post('/fee-structure/', data);
        },

        update(id, data) {
            return API.put(`/fee-structure/${id}`, data);
        },

        delete(id) {
            return API.delete(`/fee-structure/${id}`);
        },

        getYears() {
            return API.get('/fee-structure/years');
        },

        getClasses(academicYear) {
            return API.get('/fee-structure/classes', { academic_year: academicYear });
        }
    },

    // Fee Types endpoints
    feeTypes: {
        list(includeInactive = false) {
            return API.get('/fee-types/', { include_inactive: includeInactive });
        },

        get(id) {
            return API.get(`/fee-types/${id}`);
        },

        create(data) {
            return API.post('/fee-types/', data);
        },

        update(id, data) {
            return API.put(`/fee-types/${id}`, data);
        },

        delete(id) {
            return API.delete(`/fee-types/${id}`);
        }
    },

    // Users endpoints
    users: {
        list(params = {}) {
            return API.get('/users/', params);
        },

        get(id) {
            return API.get(`/users/${id}`);
        },

        create(data) {
            return API.post('/users/', data);
        },

        update(id, data) {
            return API.put(`/users/${id}`, data);
        },

        delete(id) {
            return API.delete(`/users/${id}`);
        }
    }
};

// Make API globally available
window.API = API;
