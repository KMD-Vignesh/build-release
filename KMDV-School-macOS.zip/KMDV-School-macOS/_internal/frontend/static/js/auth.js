// Authentication Module

const Auth = {
    // Check if user is authenticated
    isAuthenticated() {
        return !!localStorage.getItem(CONFIG.STORAGE_KEYS.AUTH_TOKEN);
    },

    // Get current user
    getCurrentUser() {
        const userData = localStorage.getItem(CONFIG.STORAGE_KEYS.USER_DATA);
        return userData ? JSON.parse(userData) : null;
    },

    // Get school data
    getSchoolData() {
        const schoolData = localStorage.getItem(CONFIG.STORAGE_KEYS.SCHOOL_DATA);
        return schoolData ? JSON.parse(schoolData) : null;
    },

    // Save school data
    saveSchoolData(schoolData) {
        localStorage.setItem(CONFIG.STORAGE_KEYS.SCHOOL_DATA, JSON.stringify(schoolData));
    },

    // Save auth token
    saveToken(token) {
        localStorage.setItem(CONFIG.STORAGE_KEYS.AUTH_TOKEN, token);
    },

    // Save user data
    saveUserData(userData) {
        localStorage.setItem(CONFIG.STORAGE_KEYS.USER_DATA, JSON.stringify(userData));
    },

    // Clear all auth data
    clearAuth() {
        localStorage.removeItem(CONFIG.STORAGE_KEYS.AUTH_TOKEN);
        localStorage.removeItem(CONFIG.STORAGE_KEYS.USER_DATA);
        localStorage.removeItem(CONFIG.STORAGE_KEYS.SCHOOL_DATA);
    },

    // Redirect to login
    redirectToLogin() {
        window.location.href = '/';
    },

    // Redirect to dashboard
    redirectToDashboard() {
        window.location.href = '/dashboard';
    },

    // Check auth and redirect if needed
    requireAuth() {
        if (!this.isAuthenticated()) {
            this.redirectToLogin();
            return false;
        }
        return true;
    },

    // Initialize user display
    initUserDisplay() {
        const user = this.getCurrentUser();
        const school = this.getSchoolData();

        if (user) {
            const userNameEl = document.getElementById('userName');
            if (userNameEl) {
                userNameEl.textContent = user.full_name || user.username;
            }

            // Set role-based tab visibility
            this.setTabVisibility(user);
        }

        if (school) {
            const schoolElements = document.querySelectorAll('.school-name');
            schoolElements.forEach(el => {
                el.textContent = school.school_name;
            });
        }
    },

    // Role-based tab visibility
    setTabVisibility(user) {
        const usersTab = document.getElementById('usersTab');

        if (usersTab) {
            // Show Users tab only for admin role
            if (user.role !== 'admin') {
                usersTab.style.display = 'none';
            } else {
                usersTab.style.display = 'flex';
            }
        }
    }
};

// Logout function
function logout() {
    Modal.confirm('Are you sure you want to logout?', () => {
        Auth.clearAuth();
        window.location.href = '/';
    }, {
        confirmText: 'Logout',
        confirmClass: 'btn-danger'
    });
}

// Make auth globally available
window.Auth = Auth;
window.logout = logout;

// Initialize user display on page load
if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', () => {
        if (Auth.isAuthenticated()) {
            Auth.initUserDisplay();
        }
    });
} else {
    if (Auth.isAuthenticated()) {
        Auth.initUserDisplay();
    }
}
