// Background Sync for Offline Operations

const Sync = {
    // Sync pending data
    async syncPendingData() {
        if (!navigator.onLine) {
            console.log('Cannot sync: offline');
            return;
        }

        try {
            const pendingItems = await DB.getAll('pending_sync');

            if (pendingItems.length === 0) {
                console.log('No pending items to sync');
                return;
            }

            console.log(`Syncing ${pendingItems.length} items...`);

            for (const item of pendingItems) {
                try {
                    await this.syncItem(item);
                } catch (error) {
                    console.error('Failed to sync item:', item, error);
                }
            }

            await DB.clear('pending_sync');
            console.log('Sync complete');
        } catch (error) {
            console.error('Sync failed:', error);
        }
    },

    // Sync individual item
    async syncItem(item) {
        const { type, method, endpoint, data } = item;

        switch (method) {
            case 'POST':
                return await API.post(endpoint, data);
            case 'PUT':
                return await API.put(endpoint, data);
            case 'DELETE':
                return await API.delete(endpoint);
            default:
                throw new Error(`Unknown method: ${method}`);
        }
    },

    // Queue item for sync
    async queueForSync(type, method, endpoint, data) {
        const item = {
            type,
            method,
            endpoint,
            data,
            timestamp: Date.now()
        };

        await DB.add('pending_sync', item);
        console.log('Queued for sync:', item);
    }
};

window.Sync = Sync;
