// Modal Utilities

const Modal = {
    show(modalId) {
        const modalEl = document.getElementById(modalId);
        if (modalEl) {
            const modal = new bootstrap.Modal(modalEl);
            modal.show();
        }
    },

    hide(modalId) {
        const modalEl = document.getElementById(modalId);
        if (modalEl) {
            const modal = bootstrap.Modal.getInstance(modalEl);
            if (modal) {
                modal.hide();
            }
        }
    },

    // Custom confirm dialog
    confirm(message, onConfirm, options = {}) {
        const modalEl = document.getElementById('confirmationModal');
        const bodyEl = document.getElementById('confirmationModalBody');
        const confirmBtn = document.getElementById('confirmationModalConfirm');

        if (!modalEl || !bodyEl || !confirmBtn) {
            console.error('Confirmation modal elements not found');
            return;
        }

        // Set message
        bodyEl.textContent = message;

        // Set button text and color
        confirmBtn.textContent = options.confirmText || 'Confirm';
        confirmBtn.className = `btn ${options.confirmClass || 'btn-danger'}`;

        // Remove any existing event listeners by cloning
        const newConfirmBtn = confirmBtn.cloneNode(true);
        confirmBtn.parentNode.replaceChild(newConfirmBtn, confirmBtn);

        // Add new event listener
        newConfirmBtn.addEventListener('click', () => {
            const modal = bootstrap.Modal.getInstance(modalEl);
            if (modal) {
                modal.hide();
            }
            if (onConfirm) {
                onConfirm();
            }
        });

        // Show modal
        const modal = new bootstrap.Modal(modalEl);
        modal.show();
    }
};

window.Modal = Modal;
