// Toast Notification Component

const Notification = {
    show(message, type = 'info', duration = 3000) {
        const container = document.getElementById('toastContainer');
        if (!container) {
            console.error('Toast container not found');
            alert(message); // Fallback to alert
            return;
        }

        // Ensure message is a string
        if (typeof message !== 'string') {
            message = String(message);
        }

        const toast = document.createElement('div');
        toast.className = `toast align-items-center text-white bg-${type} border-0`;
        toast.setAttribute('role', 'alert');
        toast.setAttribute('aria-live', 'assertive');
        toast.setAttribute('aria-atomic', 'true');

        const icon = this.getIcon(type);

        toast.innerHTML = `
            <div class="d-flex">
                <div class="toast-body">
                    <i class="bi ${icon} me-2"></i>
                    ${message}
                </div>
                <button type="button" class="btn-close btn-close-white me-2 m-auto"
                        data-bs-dismiss="toast" aria-label="Close"></button>
            </div>
        `;

        container.appendChild(toast);

        const bsToast = new bootstrap.Toast(toast, { delay: duration });
        bsToast.show();

        toast.addEventListener('hidden.bs.toast', () => {
            toast.remove();
        });
    },

    getIcon(type) {
        const icons = {
            success: 'bi-check-circle',
            danger: 'bi-exclamation-triangle',
            warning: 'bi-exclamation-circle',
            info: 'bi-info-circle'
        };
        return icons[type] || icons.info;
    },

    showSuccess(message, duration) {
        this.show(message, 'success', duration);
    },

    showError(message, duration) {
        this.show(message, 'danger', duration);
    },

    showWarning(message, duration) {
        this.show(message, 'warning', duration);
    },

    showInfo(message, duration) {
        this.show(message, 'info', duration);
    }
};

window.Notification = Notification;
