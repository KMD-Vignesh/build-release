// User Login Page

document.addEventListener('DOMContentLoaded', () => {
    // Check if school is authenticated
    const schoolData = Auth.getSchoolData();
    if (!schoolData) {
        window.location.href = '/';
        return;
    }

    // Display school name
    const schoolNameEl = document.getElementById('schoolName');
    if (schoolNameEl) {
        schoolNameEl.textContent = schoolData.school_name;
    }

    const form = document.getElementById('userLoginForm');

    form.addEventListener('submit', async (e) => {
        e.preventDefault();

        const username = document.getElementById('username').value.trim();
        const password = document.getElementById('password').value;

        if (!username || !password) {
            Notification.showError('Please enter username and password');
            return;
        }

        const submitBtn = form.querySelector('button[type="submit"]');
        const originalText = submitBtn.innerHTML;
        submitBtn.disabled = true;
        submitBtn.innerHTML = '<span class="spinner-border spinner-border-sm me-2"></span>Logging in...';

        try {
            const response = await API.auth.userLogin(username, password);

            // Save auth token and user data
            Auth.saveToken(response.access_token);
            Auth.saveUserData({
                id: response.user.id,
                username: response.user.username,
                full_name: response.user.full_name,
                role: response.user.role,
                email: response.user.email
            });

            Notification.showSuccess('Login successful!');

            // Redirect to dashboard
            setTimeout(() => {
                Auth.redirectToDashboard();
            }, 500);
        } catch (error) {
            Notification.showError(error.message || 'Invalid credentials');
            submitBtn.disabled = false;
            submitBtn.innerHTML = originalText;
        }
    });
});
