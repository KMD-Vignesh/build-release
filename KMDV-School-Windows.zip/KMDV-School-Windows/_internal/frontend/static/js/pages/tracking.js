// Payment Tracking Page

let currentFilters = {};
let currentView = 'payments';
let currentStudentPage = 1;
let currentPaymentPage = 1;
let allStudentData = [];
let allPaymentsData = [];
const STUDENT_PAGE_SIZE = 10;
const PAYMENT_PAGE_SIZE = 10;

document.addEventListener('DOMContentLoaded', () => {
    if (!Auth.requireAuth()) return;

    loadAcademicYears();
    loadAllClasses(); // Load all classes initially
    loadFeeTypes();
    loadPayments(1);
    loadSummary();
});

async function loadAcademicYears() {
    try {
        const years = await API.feeStructure.getYears();
        const select = document.getElementById('filterAcademicYear');
        select.innerHTML = '<option value="">All Years</option>';

        years.forEach(year => {
            const option = document.createElement('option');
            option.value = year;
            option.textContent = year;
            select.appendChild(option);
        });

        // Add event listener for academic year change
        select.addEventListener('change', async function() {
            const academicYear = this.value;
            const classSelect = document.getElementById('filterClass');

            if (academicYear) {
                // Load classes for selected academic year
                await loadClassesForYear(academicYear);
            } else {
                // Reset class dropdown if no year selected
                classSelect.innerHTML = '<option value="">All Classes</option>';
                classSelect.disabled = false;
                // Load all classes
                loadAllClasses();
            }
        });
    } catch (error) {
        console.error('Failed to load academic years:', error);
    }
}

async function loadClassesForYear(academicYear) {
    const classSelect = document.getElementById('filterClass');
    classSelect.innerHTML = '<option value="">Loading...</option>';
    classSelect.disabled = true;

    try {
        const classes = await API.feeStructure.getClasses(academicYear);

        if (classes && classes.length > 0) {
            classSelect.innerHTML = '<option value="">All Classes</option>';
            classes.forEach(className => {
                const option = document.createElement('option');
                option.value = className;
                option.textContent = className;
                classSelect.appendChild(option);
            });
            classSelect.disabled = false;
        } else {
            classSelect.innerHTML = '<option value="">No classes found for this year</option>';
            classSelect.disabled = true;
        }
    } catch (error) {
        console.error('Failed to load classes for year:', error);
        classSelect.innerHTML = '<option value="">Error loading classes</option>';
        classSelect.disabled = true;
    }
}

async function loadAllClasses() {
    const classSelect = document.getElementById('filterClass');
    const allClasses = ['LKG', 'UKG', '1', '2', '3', '4', '5', '6', '7', '8', '9', '10', '11', '12'];

    classSelect.innerHTML = '<option value="">All Classes</option>';
    allClasses.forEach(className => {
        const option = document.createElement('option');
        option.value = className;
        option.textContent = className;
        classSelect.appendChild(option);
    });
}

async function loadFeeTypes() {
    try {
        const feeTypes = await API.feeTypes.list();
        const select = document.getElementById('filterFeeType');
        select.innerHTML = '<option value="">All Types</option>';

        feeTypes.forEach(feeType => {
            const option = document.createElement('option');
            option.value = feeType.fee_code;
            option.textContent = feeType.fee_name;
            select.appendChild(option);
        });
    } catch (error) {
        console.error('Failed to load fee types:', error);
    }
}

async function loadPayments(page = 1, refetch = true) {
    currentPaymentPage = page;
    const tbody = document.getElementById('paymentsTable');

    try {
        // Only fetch if refetch is true (initial load or filter change)
        if (refetch) {
            Utils.showLoading(tbody, 'Loading...', 10);

            // Fetch all payments at once (up to 2000 records for performance)
            const response = await API.payments.list({
                ...currentFilters,
                page: 1,
                page_size: 2000
            });

            // Store all fetched payments
            allPaymentsData = response.items || [];
        }

        if (!allPaymentsData || allPaymentsData.length === 0) {
            Utils.showEmpty(tbody, 'No payments found', 10);
            document.getElementById('paymentsPagination').innerHTML = '';
            return;
        }

        // Client-side pagination - slice the data
        const start = (page - 1) * PAYMENT_PAGE_SIZE;
        const end = start + PAYMENT_PAGE_SIZE;
        const paginatedData = allPaymentsData.slice(start, end);

        tbody.innerHTML = paginatedData.map(payment => `
            <tr>
                <td>${payment.receipt_number}</td>
                <td>${Utils.formatDate(payment.payment_date)}</td>
                <td>${payment.student_name || 'N/A'}</td>
                <td>${payment.class_name || 'N/A'}</td>
                <td>${payment.section || 'N/A'}</td>
                <td>${payment.academic_year || 'N/A'}</td>
                <td>${payment.fee_type.replace('_', ' ')}</td>
                <td>${Utils.formatCurrency(payment.amount)}</td>
                <td><span class="badge bg-primary">${payment.payment_mode}</span></td>
                <td>
                    <button class="btn btn-sm btn-info" onclick="viewReceipt('${payment.id}')">
                        <i class="bi bi-eye"></i>
                    </button>
                </td>
            </tr>
        `).join('');

        // Render pagination with total from loaded data
        Utils.renderPagination({
            total: allPaymentsData.length,
            currentPage: page,
            pageSize: PAYMENT_PAGE_SIZE,
            elementId: 'paymentsPagination',
            onPageChange: 'renderPaymentsPage'
        });
    } catch (error) {
        console.error("Error in loadPayments:", error);
        Utils.showError(tbody, 'Failed to load payments', 10);
    }
}

// Render specific page without refetching
function renderPaymentsPage(page) {
    loadPayments(page, false);
}

async function loadSummary() {
    try {
        // Use student tracking data to calculate summary
        const params = {};
        if (currentFilters.academic_year) params.academic_year = currentFilters.academic_year;
        if (currentFilters.class_name) params.class_name = currentFilters.class_name;
        if (currentFilters.section) params.section = currentFilters.section;

        const studentData = await API.payments.getDetailedTracking(params);

        if (!studentData || studentData.length === 0) {
            document.getElementById('totalCollected').textContent = Utils.formatCurrency(0);
            document.getElementById('partialPayments').innerHTML = `0 <small class="text-muted fs-6">Students</small>`;
            document.getElementById('pendingPayments').textContent = Utils.formatCurrency(0);
            return;
        }

        // Calculate totals from student tracking data
        let totalCollected = 0;
        let totalPending = 0;
        let partialCount = 0;

        studentData.forEach(student => {
            totalCollected += student.total_paid || 0;
            totalPending += student.total_pending || 0;
            if (student.payment_status === 'Partial') {
                partialCount++;
            }
        });

        document.getElementById('totalCollected').textContent = Utils.formatCurrency(totalCollected);
        document.getElementById('partialPayments').innerHTML = `${partialCount} <small class="text-muted fs-6">Students</small>`;
        document.getElementById('pendingPayments').textContent = Utils.formatCurrency(totalPending);
    } catch (error) {
        console.error('Failed to load summary:', error);
    }
}

function applyFilters() {
    currentFilters = {
        academic_year: document.getElementById('filterAcademicYear')?.value || '',
        class_name: document.getElementById('filterClass')?.value || '',
        section: document.getElementById('filterSection')?.value || '',
        fee_type: document.getElementById('filterFeeType')?.value || '',
        from_date: document.getElementById('filterFromDate')?.value || '',
        to_date: document.getElementById('filterToDate')?.value || ''
    };

    // Remove empty filters
    Object.keys(currentFilters).forEach(key => {
        if (!currentFilters[key]) delete currentFilters[key];
    });

    // Reload data based on current view, reset to page 1
    if (currentView === 'students') {
        loadStudentTracking(1);
    } else {
        loadPayments(1);
    }
    loadSummary();
}

function resetFilters() {
    currentFilters = {};
    document.getElementById('filterAcademicYear').value = '';
    document.getElementById('filterClass').value = '';
    document.getElementById('filterSection').value = '';
    document.getElementById('filterFeeType').value = '';
    document.getElementById('filterFromDate').value = '';
    document.getElementById('filterToDate').value = '';

    // Reset class dropdown to show all classes
    loadAllClasses();

    // Reload data based on current view, reset to page 1
    if (currentView === 'students') {
        loadStudentTracking(1);
    } else {
        loadPayments(1);
    }
    loadSummary();
}

function exportData() {
    Notification.showInfo('Export functionality coming soon!');
}

async function viewReceipt(id) {
    try {
        // Show modal with loading state
        const modal = new bootstrap.Modal(document.getElementById('receiptViewerModal'));
        modal.show();

        // Fetch payment receipt with student details
        const receipt = await API.payments.getReceipt(id);

        // Generate receipt HTML
        const receiptHtml = generateReceiptHTML(receipt);

        // Update modal content
        document.getElementById('receiptContent').innerHTML = receiptHtml;
    } catch (error) {
        console.error('Error loading receipt:', error);
        document.getElementById('receiptContent').innerHTML = `
            <div class="text-center text-danger">
                <i class="bi bi-exclamation-circle" style="font-size: 3rem;"></i>
                <p class="mt-2">Failed to load receipt</p>
                <p class="text-muted">${error.message}</p>
            </div>
        `;
    }
}

function generateReceiptHTML(receipt) {
    const paymentDate = new Date(receipt.payment_date).toLocaleDateString('en-IN', {
        year: 'numeric',
        month: 'long',
        day: 'numeric'
    });

    const createdDate = new Date(receipt.created_at).toLocaleString('en-IN', {
        year: 'numeric',
        month: 'short',
        day: 'numeric',
        hour: '2-digit',
        minute: '2-digit'
    });

    return `
        <div class="modern-receipt" style="margin: 0 auto; font-family: 'Segoe UI', system-ui, sans-serif;">
            <!-- Header with Brand -->
            <div style="background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white; padding: 25px; border-radius: 8px 8px 0 0;">
                <div class="d-flex justify-content-between align-items-start flex-wrap">
                    <div>
                        <h2 style="margin: 0; font-weight: 700; font-size: clamp(1.3rem, 3vw, 1.8rem);">KMDV School</h2>
                        <p style="margin: 5px 0 0 0; opacity: 0.9; font-size: clamp(0.85rem, 2vw, 0.95rem);">Fee Payment Receipt</p>
                    </div>
                    <div class="text-end">
                        <div style="background: rgba(255,255,255,0.2); padding: 8px 16px; border-radius: 6px; backdrop-filter: blur(10px);">
                            <div style="font-size: 0.75rem; opacity: 0.9; margin-bottom: 4px;">RECEIPT NO.</div>
                            <div style="font-weight: 700; font-size: clamp(0.95rem, 2vw, 1.1rem); letter-spacing: 0.5px;">${receipt.receipt_number}</div>
                        </div>
                    </div>
                </div>
            </div>

            <div style="background: white; padding: clamp(20px, 4vw, 30px); border: 1px solid #e5e7eb; border-top: none; border-radius: 0 0 8px 8px;">
                <!-- Student & Parent Information -->
                <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(280px, 1fr)); gap: 25px; margin-bottom: 25px; padding-bottom: 20px; border-bottom: 2px solid #f3f4f6;">
                    <div>
                        <div style="color: #6b7280; font-size: 0.75rem; font-weight: 600; text-transform: uppercase; letter-spacing: 0.5px; margin-bottom: 12px;">
                            <i class="bi bi-person-circle"></i> Student Information
                        </div>
                        <div style="margin-bottom: 10px;">
                            <div style="font-weight: 600; color: #111827; font-size: clamp(1rem, 2vw, 1.1rem);">${receipt.student_name}</div>
                            <div style="color: #6b7280; font-size: 0.9rem; margin-top: 2px;">Admission No: ${receipt.student_admission_number}</div>
                        </div>
                        <div style="color: #374151; font-size: 0.9rem;">
                            <div><strong>Class:</strong> ${receipt.student_class} - ${receipt.student_section}</div>
                            <div><strong>Academic Year:</strong> ${receipt.academic_year}</div>
                        </div>
                    </div>

                    <div>
                        <div style="color: #6b7280; font-size: 0.75rem; font-weight: 600; text-transform: uppercase; letter-spacing: 0.5px; margin-bottom: 12px;">
                            <i class="bi bi-people-fill"></i> Parent/Guardian Details
                        </div>
                        <div style="color: #374151; font-size: 0.9rem;">
                            <div style="font-weight: 600; color: #111827; margin-bottom: 8px;">${receipt.parent_name}</div>
                            ${receipt.parent_phone ? `<div><i class="bi bi-telephone"></i> ${receipt.parent_phone}</div>` : ''}
                            ${receipt.parent_email ? `<div style="word-break: break-word;"><i class="bi bi-envelope"></i> ${receipt.parent_email}</div>` : ''}
                            ${receipt.student_address ? `<div style="margin-top: 8px; color: #6b7280; font-size: 0.85rem;"><i class="bi bi-geo-alt"></i> ${receipt.student_address}</div>` : ''}
                        </div>
                    </div>
                </div>

                <!-- Payment Details -->
                <div style="margin-bottom: 20px;">
                    <div style="color: #6b7280; font-size: 0.75rem; font-weight: 600; text-transform: uppercase; letter-spacing: 0.5px; margin-bottom: 15px;">
                        <i class="bi bi-credit-card"></i> Payment Details
                    </div>
                    <div style="background: #f9fafb; padding: 20px; border-radius: 8px; border-left: 4px solid #667eea;">
                        <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 15px;">
                            <div>
                                <div style="color: #6b7280; font-size: 0.8rem; margin-bottom: 4px;">Fee Type</div>
                                <div style="color: #111827; font-weight: 600; word-break: break-word;">${receipt.fee_type.replace(/_/g, ' ').toUpperCase()}</div>
                            </div>
                            <div>
                                <div style="color: #6b7280; font-size: 0.8rem; margin-bottom: 4px;">Payment Date</div>
                                <div style="color: #111827; font-weight: 600;">${paymentDate}</div>
                            </div>
                            <div>
                                <div style="color: #6b7280; font-size: 0.8rem; margin-bottom: 4px;">Payment Mode</div>
                                <div><span style="background: #dbeafe; color: #1e40af; padding: 4px 12px; border-radius: 12px; font-size: 0.85rem; font-weight: 600;">${receipt.payment_mode.toUpperCase()}</span></div>
                            </div>
                            ${receipt.payment_month ? `
                            <div>
                                <div style="color: #6b7280; font-size: 0.8rem; margin-bottom: 4px;">Payment Month</div>
                                <div style="color: #111827; font-weight: 600;">${receipt.payment_month}</div>
                            </div>
                            ` : ''}
                            ${receipt.payment_term ? `
                            <div>
                                <div style="color: #6b7280; font-size: 0.8rem; margin-bottom: 4px;">Payment Term</div>
                                <div style="color: #111827; font-weight: 600;">${receipt.payment_term.toUpperCase()}</div>
                            </div>
                            ` : ''}
                        </div>
                        ${receipt.remarks ? `
                        <div style="margin-top: 15px; padding-top: 15px; border-top: 1px solid #e5e7eb;">
                            <div style="color: #6b7280; font-size: 0.8rem; margin-bottom: 4px;">Remarks</div>
                            <div style="color: #374151; font-style: italic; word-break: break-word;">${receipt.remarks}</div>
                        </div>
                        ` : ''}
                    </div>
                </div>

                <!-- Amount Summary -->
                <div style="background: linear-gradient(135deg, #10b981 0%, #059669 100%); color: white; padding: 25px; border-radius: 8px; margin-bottom: 20px; box-shadow: 0 4px 6px rgba(16, 185, 129, 0.2);">
                    <div style="display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 15px;">
                        <div>
                            <div style="font-size: 0.9rem; opacity: 0.9; margin-bottom: 5px;">Amount Paid</div>
                            <div style="font-size: clamp(1.8rem, 5vw, 2.5rem); font-weight: 700; line-height: 1;">₹${parseFloat(receipt.amount).toLocaleString('en-IN', {minimumFractionDigits: 2, maximumFractionDigits: 2})}</div>
                        </div>
                        <div style="text-align: right;">
                            <i class="bi bi-check-circle-fill" style="font-size: clamp(2rem, 5vw, 3rem); opacity: 0.3;"></i>
                        </div>
                    </div>
                </div>

                <!-- Transaction Info -->
                <div style="background: #fffbeb; border: 1px solid #fcd34d; border-radius: 6px; padding: 15px; margin-bottom: 20px;">
                    <div style="display: flex; align-items-start; gap: 10px;">
                        <i class="bi bi-info-circle-fill" style="color: #f59e0b; font-size: 1.2rem; flex-shrink: 0;"></i>
                        <div style="flex: 1; overflow-wrap: break-word;">
                            <div style="font-size: 0.85rem; color: #92400e; margin-bottom: 5px;">
                                <strong>Transaction Details</strong>
                            </div>
                            <div style="font-size: 0.8rem; color: #78350f; word-break: break-all;">
                                Transaction ID: <code style="background: rgba(0,0,0,0.1); padding: 2px 6px; border-radius: 3px;">${receipt.id}</code>
                            </div>
                            <div style="font-size: 0.8rem; color: #78350f; margin-top: 3px;">
                                Generated on: ${createdDate}
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Footer Note -->
                <div style="text-align: center; padding-top: 20px; border-top: 1px solid #e5e7eb;">
                    <p style="color: #9ca3af; font-size: 0.8rem; margin: 0;">
                        <i class="bi bi-shield-check"></i> This is a computer-generated receipt and does not require a physical signature.
                    </p>
                    <p style="color: #d1d5db; font-size: 0.75rem; margin: 8px 0 0 0;">
                        For any queries, please contact the school office.
                    </p>
                </div>
            </div>
        </div>
    `;
}

function printReceipt() {
    const receiptContent = document.getElementById('receiptContent').innerHTML;
    const printWindow = window.open('', '', 'width=800,height=600');

    printWindow.document.write(`
        <!DOCTYPE html>
        <html>
        <head>
            <title>Payment Receipt</title>
            <link rel="stylesheet" href="/static/css/bootstrap.min.css">
            <link rel="stylesheet" href="/static/css/bootstrap-icons.css">
            <style>
                body { padding: 20px; }
                @media print {
                    .no-print { display: none; }
                }
            </style>
        </head>
        <body>
            ${receiptContent}
            <script>
                window.onload = function() {
                    window.print();
                    setTimeout(function() { window.close(); }, 100);
                };
            </script>
        </body>
        </html>
    `);

    printWindow.document.close();
}

// View Switcher
function switchView(view) {
    currentView = view;

    if (view === 'payments') {
        document.getElementById('paymentRecordsView').style.display = 'block';
        document.getElementById('studentTrackingView').style.display = 'none';
        document.getElementById('btnPaymentView').classList.add('btn-primary');
        document.getElementById('btnPaymentView').classList.remove('btn-outline-primary');
        document.getElementById('btnStudentView').classList.remove('btn-primary');
        document.getElementById('btnStudentView').classList.add('btn-outline-primary');
        loadPayments(1);
    } else {
        document.getElementById('paymentRecordsView').style.display = 'none';
        document.getElementById('studentTrackingView').style.display = 'block';
        document.getElementById('btnPaymentView').classList.remove('btn-primary');
        document.getElementById('btnPaymentView').classList.add('btn-outline-primary');
        document.getElementById('btnStudentView').classList.add('btn-primary');
        document.getElementById('btnStudentView').classList.remove('btn-outline-primary');
        loadStudentTracking(1);
    }
}

// Store student data globally for breakdown modal
let studentDataCache = {};

// Load student-wise tracking
async function loadStudentTracking(page = 1, refetch = true) {
    currentStudentPage = page;
    const tbody = document.getElementById('studentTrackingTable');

    try {
        // Only fetch if refetch is true (initial load or filter change)
        if (refetch) {
            tbody.innerHTML = '<tr><td colspan="10" class="text-center">Loading...</td></tr>';

            const params = {};
            if (currentFilters.academic_year) params.academic_year = currentFilters.academic_year;
            if (currentFilters.class_name) params.class_name = currentFilters.class_name;
            if (currentFilters.section) params.section = currentFilters.section;

            allStudentData = await API.payments.getDetailedTracking(params);

            // Sort by academic year (newest first)
            allStudentData.sort((a, b) => {
                const yearA = a.academic_year || '';
                const yearB = b.academic_year || '';
                return yearB.localeCompare(yearA);
            });
        }

        if (!allStudentData || allStudentData.length === 0) {
            tbody.innerHTML = '<tr><td colspan="10" class="text-center">No students found</td></tr>';
            document.getElementById('studentTrackingPagination').innerHTML = '';
            return;
        }

        // Client-side pagination
        const start = (page - 1) * STUDENT_PAGE_SIZE;
        const end = start + STUDENT_PAGE_SIZE;
        const paginatedData = allStudentData.slice(start, end);

        // Clear cache
        studentDataCache = {};

        tbody.innerHTML = paginatedData.map((student, index) => {
            // Store student data in cache
            const cacheKey = `student_${index}`;
            studentDataCache[cacheKey] = student;

            const statusBadge = student.payment_status === 'Paid'
                ? '<span class="badge bg-success">Paid</span>'
                : student.payment_status === 'Partial'
                ? '<span class="badge bg-warning">Partial</span>'
                : '<span class="badge bg-danger">Pending</span>';

            return `
                <tr>
                    <td>${escapeHtml(student.admission_number)}</td>
                    <td>${escapeHtml(student.student_name)}</td>
                    <td>${escapeHtml(student.class_name)}</td>
                    <td>${escapeHtml(student.section)}</td>
                    <td>${escapeHtml(student.academic_year || 'N/A')}</td>
                    <td>₹${student.total_fee.toFixed(2)}</td>
                    <td>₹${student.total_paid.toFixed(2)}</td>
                    <td>₹${student.total_pending.toFixed(2)}</td>
                    <td>${statusBadge}</td>
                    <td>
                        <button class="btn btn-sm btn-info" onclick="viewFeeBreakdown('${cacheKey}')">
                            <i class="bi bi-list-check"></i>
                        </button>
                    </td>
                </tr>
            `;
        }).join('');

        // Render pagination
        Utils.renderPagination({
            total: allStudentData.length,
            currentPage: page,
            pageSize: STUDENT_PAGE_SIZE,
            elementId: 'studentTrackingPagination',
            onPageChange: 'renderStudentTrackingPage'
        });
    } catch (error) {
        console.error('Error loading student tracking:', error);
        tbody.innerHTML = `<tr><td colspan="10" class="text-center text-danger">Error: ${error.message}</td></tr>`;
    }
}

// Render specific page without refetching
function renderStudentTrackingPage(page) {
    loadStudentTracking(page, false);
}

// Escape HTML helper
function escapeHtml(text) {
    if (!text) return '';
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
}

// View fee breakdown
function viewFeeBreakdown(cacheKey) {
    const student = studentDataCache[cacheKey];

    if (!student) {
        console.error('Student not found in cache:', cacheKey);
        return;
    }

    document.getElementById('breakdownStudentName').textContent =
        `${student.student_name} (${student.class_name}-${student.section})`;

    const tbody = document.getElementById('feeBreakdownTable');
    tbody.innerHTML = '';

    if (!student.fee_breakdown || Object.keys(student.fee_breakdown).length === 0) {
        tbody.innerHTML = '<tr><td colspan="4" class="text-center">No fee breakdown available</td></tr>';
    } else {
        for (const [feeType, breakdown] of Object.entries(student.fee_breakdown)) {
            const row = document.createElement('tr');
            row.innerHTML = `
                <td>${escapeHtml(feeType)}</td>
                <td>₹${breakdown.total.toFixed(2)}</td>
                <td>₹${breakdown.paid.toFixed(2)}</td>
                <td>₹${breakdown.pending.toFixed(2)}</td>
            `;
            tbody.appendChild(row);
        }
    }

    const modal = new bootstrap.Modal(document.getElementById('feeBreakdownModal'));
    modal.show();
}
