// Users Page

let currentPage = 1;
let currentFilters = {};
let allUsersData = [];
const PAGE_SIZE = 10;

document.addEventListener('DOMContentLoaded', () => {
    if (!Auth.requireAuth()) return;

    // Check if user is admin
    const currentUser = Auth.getCurrentUser();
    if (!currentUser || currentUser.role !== 'admin') {
        Notification.showError('Access denied. Only administrators can access this page.');
        setTimeout(() => {
            window.location.href = '/dashboard';
        }, 2000);
        return;
    }

    loadUsers(1);
    initializeFilters();
    initializeAddUserForm();
    initializeEditUserForm();
});

async function loadUsers(page = 1, refetch = true) {
    currentPage = page;
    const tbody = document.getElementById('usersTable');

    try {
        // Only fetch if refetch is true (initial load or filter change)
        if (refetch) {
            Utils.showLoading(tbody);

            const params = { page: 1, page_size: 100, ...currentFilters };
            const response = await API.users.list(params);
            allUsersData = response.users || [];
        }

        if (!allUsersData || allUsersData.length === 0) {
            Utils.showEmpty(tbody, 'No users found');
            document.getElementById('pagination').innerHTML = '';
            return;
        }

        // Client-side pagination
        const start = (page - 1) * PAGE_SIZE;
        const end = start + PAGE_SIZE;
        const paginatedData = allUsersData.slice(start, end);

        tbody.innerHTML = paginatedData.map(user => `
            <tr>
                <td>${user.username}</td>
                <td>${user.email || 'N/A'}</td>
                <td>${user.full_name}</td>
                <td><span class="badge bg-${getRoleBadgeColor(user.role)}">${user.role}</span></td>
                <td>
                    <span class="badge bg-${user.is_active ? 'success' : 'danger'}">
                        ${user.is_active ? 'Active' : 'Inactive'}
                    </span>
                </td>
                <td>
                    <button class="btn btn-sm btn-primary" onclick="showEditUser('${user.id}')">
                        <i class="bi bi-pencil"></i>
                    </button>
                    <button class="btn btn-sm btn-danger" onclick="deleteUser('${user.id}')">
                        <i class="bi bi-trash"></i>
                    </button>
                </td>
            </tr>
        `).join('');

        Utils.renderPagination({
            total: allUsersData.length,
            currentPage: page,
            pageSize: PAGE_SIZE,
            elementId: 'pagination',
            onPageChange: 'renderUsersPage'
        });
    } catch (error) {
        Utils.showError(tbody, 'Failed to load users');
        Notification.showError('Failed to load users');
    }
}

// Render specific page without refetching
function renderUsersPage(page) {
    loadUsers(page, false);
}

function getRoleBadgeColor(role) {
    const colors = {
        'admin': 'danger',
        'staff': 'primary',
        'accountant': 'info'
    };
    return colors[role] || 'secondary';
}

function initializeFilters() {
    const searchInput = document.getElementById('searchUser');
    const roleFilter = document.getElementById('filterRole');
    const statusFilter = document.getElementById('filterStatus');

    if (searchInput) {
        searchInput.addEventListener('input', Utils.debounce((e) => {
            currentFilters.search = e.target.value;
            loadUsers(1);
        }, 500));
    }

    if (roleFilter) {
        roleFilter.addEventListener('change', (e) => {
            currentFilters.role = e.target.value;
            loadUsers(1);
        });
    }

    if (statusFilter) {
        statusFilter.addEventListener('change', (e) => {
            currentFilters.is_active = e.target.value;
            loadUsers(1);
        });
    }
}

function resetFilters() {
    currentFilters = {};
    document.getElementById('searchUser').value = '';
    document.getElementById('filterRole').value = '';
    document.getElementById('filterStatus').value = '';
    loadUsers(1);
}

function initializeAddUserForm() {
    const form = document.getElementById('addUserForm');
    if (!form) return;

    form.addEventListener('submit', async (e) => {
        e.preventDefault();

        const formData = new FormData(form);
        const data = Object.fromEntries(formData.entries());

        // Convert checkbox value
        data.is_active = form.querySelector('[name="is_active"]').checked;

        try {
            await API.users.create(data);
            Notification.showSuccess('User added successfully');
            Modal.hide('addUserModal');
            form.reset();
            loadUsers(currentPage);
        } catch (error) {
            Notification.showError(error.message || 'Failed to add user');
        }
    });
}

function initializeEditUserForm() {
    const form = document.getElementById('editUserForm');
    if (!form) return;

    form.addEventListener('submit', async (e) => {
        e.preventDefault();

        const formData = new FormData(form);
        const data = Object.fromEntries(formData.entries());

        // Convert checkbox value
        data.is_active = form.querySelector('[name="is_active"]').checked;

        const userId = data.user_id;
        delete data.user_id;

        // Remove password if empty
        if (!data.password) {
            delete data.password;
        }

        try {
            await API.users.update(userId, data);
            Notification.showSuccess('User updated successfully');
            Modal.hide('editUserModal');
            loadUsers(currentPage);
        } catch (error) {
            Notification.showError(error.message || 'Failed to update user');
        }
    });
}

async function showEditUser(userId) {
    try {
        const user = await API.users.get(userId);

        // Populate form
        document.getElementById('editUserId').value = user.id;
        document.getElementById('editUsername').value = user.username;
        document.getElementById('editEmail').value = user.email || '';
        document.getElementById('editFullName').value = user.full_name;
        document.getElementById('editRole').value = user.role;
        document.getElementById('editIsActive').checked = user.is_active;
        document.getElementById('editPassword').value = '';

        // Show modal
        Modal.show('editUserModal');
    } catch (error) {
        Notification.showError('Failed to load user details');
    }
}

async function deleteUser(id) {
    Modal.confirm('Are you sure you want to delete this user?', async () => {
        try {
            await API.users.delete(id);
            Notification.showSuccess('User deleted successfully');
            loadUsers(currentPage);
        } catch (error) {
            Notification.showError('Failed to delete user');
        }
    });
}

