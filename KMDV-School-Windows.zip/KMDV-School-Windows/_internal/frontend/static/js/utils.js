// Utility Functions

const Utils = {
    // Format currency
    formatCurrency(amount) {
        return new Intl.NumberFormat('en-IN', {
            style: 'currency',
            currency: 'INR',
            minimumFractionDigits: 0,
            maximumFractionDigits: 2
        }).format(amount);
    },

    // Format date
    formatDate(dateString) {
        const date = new Date(dateString);
        return date.toLocaleDateString('en-IN', {
            year: 'numeric',
            month: 'short',
            day: 'numeric'
        });
    },

    // Format date for input
    formatDateInput(dateString) {
        const date = new Date(dateString);
        return date.toISOString().split('T')[0];
    },

    // Get today's date in YYYY-MM-DD format
    getTodayDate() {
        return new Date().toISOString().split('T')[0];
    },

    // Debounce function
    debounce(func, wait) {
        let timeout;
        return function executedFunction(...args) {
            const later = () => {
                clearTimeout(timeout);
                func(...args);
            };
            clearTimeout(timeout);
            timeout = setTimeout(later, wait);
        };
    },

    // Get query parameters
    getQueryParam(param) {
        const urlParams = new URLSearchParams(window.location.search);
        return urlParams.get(param);
    },

    // Set query parameters
    setQueryParam(param, value) {
        const url = new URL(window.location);
        url.searchParams.set(param, value);
        window.history.pushState({}, '', url);
    },

    // Capitalize first letter
    capitalize(str) {
        return str.charAt(0).toUpperCase() + str.slice(1);
    },

    // Generate unique ID
    generateId() {
        return Date.now().toString(36) + Math.random().toString(36).substr(2);
    },

    // Validate email
    isValidEmail(email) {
        const re = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        return re.test(email);
    },

    // Validate phone
    isValidPhone(phone) {
        const re = /^[6-9]\d{9}$/;
        return re.test(phone);
    },

    // Show loading state
    showLoading(element, text = 'Loading...', colspan = null) {
        if (typeof element === 'string') {
            element = document.querySelector(element);
        }
        if (element) {
            let content = `
                <div class="text-center p-4">
                    <div class="spinner-border text-primary" role="status">
                        <span class="visually-hidden">${text}</span>
                    </div>
                    <p class="mt-2 text-muted">${text}</p>
                </div>
            `;
            if (colspan) {
                content = `<tr><td colspan="${colspan}">${content}</td></tr>`;
            }
            element.innerHTML = content;
        }
    },

    // Show error message
    showError(element, message, colspan = null) {
        if (typeof element === 'string') {
            element = document.querySelector(element);
        }
        if (element) {
            let content = `
                <div class="alert alert-danger" role="alert">
                    <i class="bi bi-exclamation-triangle"></i> ${message}
                </div>
            `;
            if (colspan) {
                content = `<tr><td colspan="${colspan}">${content}</td></tr>`;
            }
            element.innerHTML = content;
        }
    },

    // Show empty state
    showEmpty(element, message = 'No data found', colspan = null) {
        if (typeof element === 'string') {
            element = document.querySelector(element);
        }
        if (element) {
            let content = `
                <div class="text-center p-4 text-muted">
                    <i class="bi bi-inbox" style="font-size: 3rem;"></i>
                    <p class="mt-2">${message}</p>
                </div>
            `;
            if (colspan) {
                content = `<tr><td colspan="${colspan}">${content}</td></tr>`;
            }
            element.innerHTML = content;
        }
    },

    // Escape HTML to prevent XSS
    escapeHtml(text) {
        if (text == null) return '';
        const div = document.createElement('div');
        div.textContent = text;
        return div.innerHTML;
    },

    // Render pagination with modern design
    renderPagination(config) {
        const {
            total,              // Total number of items
            currentPage = 1,    // Current page number
            pageSize = 10,      // Items per page
            elementId = 'pagination', // ID of pagination container
            onPageChange        // Callback function(page)
        } = config;

        const totalPages = Math.ceil(total / pageSize);
        const paginationEl = document.getElementById(elementId);

        if (!paginationEl) return;

        // Don't show pagination if only one page or no items
        if (totalPages <= 1) {
            paginationEl.innerHTML = '';
            return;
        }

        let html = '';

        // Previous button
        html += `
            <li class="page-item ${currentPage === 1 ? 'disabled' : ''}">
                <a class="page-link" href="javascript:void(0)" onclick="${onPageChange}(${currentPage - 1})" ${currentPage === 1 ? 'tabindex="-1"' : ''} style="color: #2c3e50; border-color: #2c3e50; background-color: white;">
                    <i class="bi bi-chevron-left"></i>
                </a>
            </li>
        `;

        // Page numbers with ellipsis for large page counts
        const maxVisible = 5;
        let startPage = Math.max(1, currentPage - Math.floor(maxVisible / 2));
        let endPage = Math.min(totalPages, startPage + maxVisible - 1);

        if (endPage - startPage < maxVisible - 1) {
            startPage = Math.max(1, endPage - maxVisible + 1);
        }

        // First page
        if (startPage > 1) {
            html += `
                <li class="page-item">
                    <a class="page-link" href="javascript:void(0)" onclick="${onPageChange}(1)" style="color: #2c3e50; border-color: #2c3e50; background-color: white;">1</a>
                </li>
            `;
            if (startPage > 2) {
                html += `<li class="page-item disabled"><span class="page-link" style="color: #2c3e50; border-color: #2c3e50; background-color: white;">...</span></li>`;
            }
        }

        // Page numbers
        for (let i = startPage; i <= endPage; i++) {
            const isActive = i === currentPage;
            const style = isActive ? '' : ' style="color: #2c3e50; border-color: #2c3e50; background-color: white;"';
            html += `
                <li class="page-item ${isActive ? 'active' : ''}">
                    <a class="page-link" href="javascript:void(0)" onclick="${onPageChange}(${i})"${style}>${i}</a>
                </li>
            `;
        }

        // Last page
        if (endPage < totalPages) {
            if (endPage < totalPages - 1) {
                html += `<li class="page-item disabled"><span class="page-link" style="color: #2c3e50; border-color: #2c3e50; background-color: white;">...</span></li>`;
            }
            html += `
                <li class="page-item">
                    <a class="page-link" href="javascript:void(0)" onclick="${onPageChange}(${totalPages})" style="color: #2c3e50; border-color: #2c3e50; background-color: white;">${totalPages}</a>
                </li>
            `;
        }

        // Next button
        html += `
            <li class="page-item ${currentPage === totalPages ? 'disabled' : ''}">
                <a class="page-link" href="javascript:void(0)" onclick="${onPageChange}(${currentPage + 1})" ${currentPage === totalPages ? 'tabindex="-1"' : ''} style="color: #2c3e50; border-color: #2c3e50; background-color: white;">
                    <i class="bi bi-chevron-right"></i>
                </a>
            </li>
        `;

        paginationEl.innerHTML = html;

        // Add info text
        const start = (currentPage - 1) * pageSize + 1;
        const end = Math.min(currentPage * pageSize, total);
        const infoHtml = `<div class="pagination-info text-muted small mb-2">Showing ${start}-${end} of ${total} items</div>`;

        if (paginationEl.previousElementSibling?.classList.contains('pagination-info')) {
            paginationEl.previousElementSibling.remove();
        }
        paginationEl.insertAdjacentHTML('beforebegin', infoHtml);
    }
};

// Make utils globally available
window.Utils = Utils;
