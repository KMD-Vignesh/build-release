# KMDV School Management System - Windows

## How to Run

1. Double-click `kmdv_school.exe` to start the server

   OR

   Open Command Prompt/PowerShell in this folder and run:
   kmdv_school.exe

2. Wait for the server to start (you'll see log messages)

3. Open your browser and go to:
   http://localhost:8000

## Demo Login Credentials

**School Login:**
- School Code: demohigh
- Password: demo123

OR

- School Code: stmarys
- Password: mary123

**User Login (after school login):**
- Username: admin
- Password: admin123

## Data Storage

**IMPORTANT:** Your data is stored in this folder:

    KMDV-School-Windows\backend\data\school.db

- All your data is saved in this database file
- You can backup this file to preserve your data
- To reset to demo data, restore from the original ZIP
- Keep this entire folder together - don't move just the .exe file

## Stopping the Server

Press Ctrl+C in the command window to stop the server.

## Troubleshooting

### Windows Defender/Antivirus Warning
If Windows shows a security warning:
1. Click "More info"
2. Click "Run anyway"

This is normal for unsigned executables.

### Firewall Prompt
If Windows Firewall prompts you:
- Click "Allow access" to let the server run

### Port Already in Use
If you see "port 8000 already in use":
- Close any other applications using port 8000
- Or restart your computer

### Application Doesn't Start
1. Make sure all files are extracted (don't run from ZIP)
2. Check if antivirus blocked the application
3. Try running as Administrator (right-click > Run as administrator)

### Data Not Saving
Check that the backend\data\ folder is writable.
Your data is saved in backend\data\school.db in the extracted folder.

## Support
For issues, please contact your administrator.
